async function handler({
  name,
  email,
  birth_date,
  phone,
  rank_id,
  temp_password,
}) {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Je moet ingelogd zijn om deze actie uit te voeren" };
  }

  const admins = await sql`
    SELECT is_admin FROM auth_users WHERE id = ${session.user.id}
  `;

  if (!admins[0]?.is_admin) {
    return {
      error: "Geen toegang. Alleen administrators kunnen leden toevoegen.",
    };
  }

  try {
    const result = await sql.transaction(async (sql) => {
      const [user] = await sql`
        INSERT INTO auth_users (
          name, 
          email, 
          birth_date, 
          phone, 
          rank_id, 
          temp_password
        )
        VALUES (
          ${name}, 
          ${email}, 
          ${birth_date}, 
          ${phone}, 
          ${rank_id}, 
          true
        )
        RETURNING id
      `;

      await sql`
        INSERT INTO auth_accounts (
          type, 
          provider, 
          "providerAccountId", 
          "userId", 
          password
        )
        VALUES (
          'credentials', 
          'email', 
          ${email}, 
          ${user.id}, 
          ${temp_password}
        )
      `;

      return user;
    });

    return { success: true, message: "Lid succesvol toegevoegd" };
  } catch (error) {
    console.error("Error creating member:", error);
    return { error: "Er is een fout opgetreden bij het aanmaken van het lid" };
  }
}