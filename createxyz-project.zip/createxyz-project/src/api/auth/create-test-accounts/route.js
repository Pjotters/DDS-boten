async function handler({ email, password, name, isAdmin = false }) {
  try {
    if (!email && !password) {
      const testPassword = "Pjotters1!";
      const adminPassword = "Admin1!";

      await sql.transaction(async (txn) => [
        txn(
          "WITH new_user AS (INSERT INTO auth_users (email, name, is_admin) VALUES ($1, $2, $3) RETURNING id) INSERT INTO auth_accounts (\"userId\", type, provider, \"providerAccountId\", password) SELECT id, 'credentials', 'email', $1, $4 FROM new_user",
          ["test@pjotters.com", "Test User", false, await hash(testPassword)]
        ),

        txn(
          "WITH new_user AS (INSERT INTO auth_users (email, name, is_admin) VALUES ($1, $2, $3) RETURNING id) INSERT INTO auth_accounts (\"userId\", type, provider, \"providerAccountId\", password) SELECT id, 'credentials', 'email', $1, $4 FROM new_user",
          ["admin@pjotters.com", "Admin User", true, await hash(adminPassword)]
        ),
      ]);

      return {
        success: true,
        message: "Test accounts aangemaakt",
        accounts: [
          { email: "test@pjotters.com", password: testPassword },
          { email: "admin@pjotters.com", password: adminPassword },
        ],
      };
    }

    const hashedPassword = await hash(password);

    const [user] = await sql.transaction(async (txn) => [
      txn(
        'WITH new_user AS (INSERT INTO auth_users (email, name, is_admin) VALUES ($1, $2, $3) RETURNING id) INSERT INTO auth_accounts ("userId", type, provider, "providerAccountId", password) SELECT id, \'credentials\', \'email\', $1, $4 FROM new_user RETURNING "userId"',
        [email.toLowerCase(), name, isAdmin, hashedPassword]
      ),
    ]);

    return {
      success: true,
      userId: user[0].userId,
    };
  } catch (error) {
    console.error("Error creating account:", error);
    return { error: "Kon geen account aanmaken" };
  }
}