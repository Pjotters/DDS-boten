async function handler({ email, password }) {
  if (!email || !password) {
    return { error: "Email en wachtwoord zijn verplicht" };
  }

  try {
    const [users] = await sql(
      'SELECT u.id, u.email, u.is_admin, u.name, a.password FROM auth_users u JOIN auth_accounts a ON a."userId" = u.id WHERE LOWER(u.email) = LOWER($1) AND a.type = $2 LIMIT 1',
      [email.trim(), "credentials"]
    );

    if (!users || users.length === 0) {
      return { error: "Ongeldige inloggegevens" };
    }

    const user = users[0];

    if (!user.password || user.password !== password) {
      return { error: "Ongeldige inloggegevens" };
    }

    return {
      id: user.id,
      email: user.email,
      name: user.name,
      isAdmin: user.is_admin,
    };
  } catch (error) {
    console.error("Login error:", error);
    return { error: "Er is een fout opgetreden bij het inloggen" };
  }
}