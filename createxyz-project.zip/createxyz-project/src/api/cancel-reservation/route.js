async function handler({ reservationId }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Je moet ingelogd zijn om een reservering te annuleren" };
  }

  const reservations = await sql`
    SELECT * FROM reservations 
    WHERE id = ${reservationId}
  `;

  if (!reservations.length) {
    return { error: "Reservering niet gevonden" };
  }

  const reservation = reservations[0];

  const userRanks = await sql`
    SELECT ranks.permission_level 
    FROM auth_users 
    JOIN ranks ON auth_users.rank_id = ranks.id 
    WHERE auth_users.id = ${session.user.id}
  `;

  if (!userRanks.length) {
    return { error: "Gebruiker niet gevonden" };
  }

  if (
    reservation.user_id !== session.user.id &&
    userRanks[0].permission_level < 80
  ) {
    return { error: "Je hebt geen rechten om deze reservering te annuleren" };
  }

  await sql`
    UPDATE reservations 
    SET status = 'cancelled' 
    WHERE id = ${reservationId}
  `;

  return { success: true };
}