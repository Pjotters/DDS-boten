async function handler({ currentPassword, newPassword }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Je moet ingelogd zijn om je wachtwoord te wijzigen" };
  }

  if (!currentPassword || !newPassword) {
    return { error: "Beide wachtwoorden zijn verplicht" };
  }

  if (newPassword.length < 8) {
    return {
      error: "Het nieuwe wachtwoord moet minimaal 8 karakters lang zijn",
    };
  }

  if (currentPassword === newPassword) {
    return {
      error:
        "Het nieuwe wachtwoord mag niet hetzelfde zijn als het huidige wachtwoord",
    };
  }

  try {
    const accounts = await sql(
      'SELECT id, password FROM auth_accounts WHERE "userId" = $1 AND type = $2 LIMIT 1',
      [session.user.id, "credentials"]
    );

    if (!accounts.length) {
      return { error: "Geen account gevonden met wachtwoord authenticatie" };
    }

    const currentPasswordMatches = await fetch("/api/verify-password", {
      method: "POST",
      body: JSON.stringify({
        hashedPassword: accounts[0].password,
        plainPassword: currentPassword,
      }),
    }).then((r) => r.json());

    if (!currentPasswordMatches.verified) {
      return { error: "Het huidige wachtwoord is onjuist" };
    }

    const hashedPassword = await fetch("/api/hash-password", {
      method: "POST",
      body: JSON.stringify({ password: newPassword }),
    })
      .then((r) => r.json())
      .then((r) => r.hashedPassword);

    await sql.transaction([
      sql("UPDATE auth_accounts SET password = $1 WHERE id = $2", [
        hashedPassword,
        accounts[0].id,
      ]),
      sql("UPDATE auth_users SET temp_password = $1 WHERE id = $2", [
        false,
        session.user.id,
      ]),
    ]);

    return {
      success: true,
      message: "Wachtwoord succesvol gewijzigd",
    };
  } catch (error) {
    return {
      error:
        "Er is een fout opgetreden bij het wijzigen van het wachtwoord. Probeer het later opnieuw.",
    };
  }
}