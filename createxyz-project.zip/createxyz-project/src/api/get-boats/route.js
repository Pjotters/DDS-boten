async function handler() {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Je moet ingelogd zijn om boten te kunnen zien" };
  }

  const boats = await sql`
    SELECT 
      id,
      name,
      type,
      weight_class,
      exam_level,
      status,
      min_rank_id
    FROM boats
    ORDER BY name ASC
  `;

  return { boats };
}