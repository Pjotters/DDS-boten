async function handler() {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Je moet ingelogd zijn om deze actie uit te voeren" };
  }

  const adminCheck = await sql`
    SELECT is_admin FROM auth_users WHERE id = ${session.user.id}
  `;

  if (!adminCheck[0]?.is_admin) {
    return {
      error: "Geen toegang. Alleen administrators kunnen leden bekijken.",
    };
  }

  const members = await sql`
    SELECT 
      u.id,
      u.name,
      u.email,
      u.birth_date,
      u.phone,
      u.temp_password,
      r.name as rank_name,
      r.id as rank_id
    FROM auth_users u
    LEFT JOIN ranks r ON u.rank_id = r.id
    ORDER BY u.name ASC
  `;

  return { members };
}