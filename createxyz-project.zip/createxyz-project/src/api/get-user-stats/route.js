async function handler() {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Niet ingelogd" };
  }

  const admin = await sql`
    SELECT is_admin FROM auth_users WHERE id = ${session.user.id}
  `;

  if (!admin[0]?.is_admin) {
    return { error: "Geen admin rechten" };
  }

  const stats = await sql`
    SELECT
      (SELECT COUNT(*) FROM auth_users) as total_users,
      (SELECT COUNT(*) FROM reservations WHERE status = 'active') as active_reservations,
      (SELECT COUNT(*) FROM boat_damages WHERE status = 'open') as open_damages,
      (SELECT COUNT(*) FROM user_exams WHERE status = 'pending') as pending_exams,
      (SELECT json_agg(row_to_json(stats)) FROM (
        SELECT b.type, COUNT(*) 
        FROM reservations r 
        JOIN boats b ON r.boat_id = b.id 
        WHERE r.created_at > NOW() - INTERVAL '30 days'
        GROUP BY b.type
      ) stats) as boat_usage_by_type
  `;

  return stats[0];
}