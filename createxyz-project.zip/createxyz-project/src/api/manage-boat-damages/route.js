async function handler({
  action,
  boatId,
  description,
  damageId,
  status,
  severity,
}) {
  const session = getSession();

  switch (action) {
    case "report":
      if (!session?.user?.id) {
        return { error: "Je moet ingelogd zijn om schade te melden" };
      }
      if (!boatId || !description) {
        return { error: "Boot en beschrijving zijn verplicht" };
      }

      const newDamage = await sql`
        INSERT INTO boat_damages (boat_id, reported_by, description, severity)
        VALUES (${boatId}, ${session.user.id}, ${description}, ${
        severity || "medium"
      })
        RETURNING *
      `;

      return { damage: newDamage[0] };

    case "update":
      if (!session?.user?.id) {
        return { error: "Je moet ingelogd zijn om schade te updaten" };
      }
      if (!damageId) {
        return { error: "Damage ID is verplicht" };
      }

      const userRank = await sql`
        SELECT ranks.permission_level 
        FROM auth_users 
        JOIN ranks ON auth_users.rank_id = ranks.id 
        WHERE auth_users.id = ${session.user.id}
      `;

      if (!userRank.length || userRank[0].permission_level < 80) {
        return { error: "Geen rechten om schade te updaten" };
      }

      let updateQuery;
      if (status === "resolved") {
        updateQuery = await sql`
          UPDATE boat_damages 
          SET status = ${status}, 
              resolved_at = NOW(),
              resolved_by = ${session.user.id}
          WHERE id = ${damageId}
          RETURNING *
        `;
      } else {
        updateQuery = await sql`
          UPDATE boat_damages 
          SET status = ${status}
          WHERE id = ${damageId}
          RETURNING *
        `;
      }

      return { damage: updateQuery[0] };

    case "list":
      const damages = await sql`
        SELECT 
          boat_damages.*,
          boats.name as boat_name,
          auth_users.name as reporter_name
        FROM boat_damages
        JOIN boats ON boat_damages.boat_id = boats.id
        JOIN auth_users ON boat_damages.reported_by = auth_users.id
        ORDER BY boat_damages.reported_at DESC
      `;

      return { damages };

    default:
      return { error: "Invalid action" };
  }
}