async function handler({ action, examId, userId, status, notes }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Niet ingelogd" };
  }

  const admin = await sql`
    SELECT is_admin FROM auth_users WHERE id = ${session.user.id}
  `;

  if (!admin[0]?.is_admin) {
    return { error: "Geen admin rechten" };
  }

  switch (action) {
    case "schedule":
      await sql`
        INSERT INTO user_exams (user_id, exam_id, examiner_id)
        VALUES (${userId}, ${examId}, ${session.user.id})
      `;
      break;

    case "complete":
      await sql.transaction(async (sql) => {
        await sql`
          UPDATE user_exams 
          SET status = ${status},
              completed_at = CURRENT_TIMESTAMP,
              notes = ${notes}
          WHERE id = ${examId}
        `;

        if (status === "passed") {
          const exam = await sql`
            SELECT next_rank_id FROM exams WHERE id = ${examId}
          `;

          if (exam[0]?.next_rank_id) {
            await sql`
              UPDATE auth_users
              SET rank_id = ${exam[0].next_rank_id}
              WHERE id = ${userId}
            `;
          }
        }
      });
      break;

    default:
      return { error: "Ongeldige actie" };
  }

  return { success: true };
}