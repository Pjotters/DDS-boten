async function handler({ action, userId, rankId }) {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Niet ingelogd" };
  }

  const adminCheck = await sql`
    SELECT rank_id FROM auth_users 
    WHERE id = ${session.user.id} 
    AND rank_id IN (
      SELECT id FROM ranks WHERE permission_level = 100
    )
  `;

  if (!adminCheck.length) {
    return { error: "Geen admin rechten" };
  }

  try {
    switch (action) {
      case "getRanks":
        const ranks = await sql`
          SELECT * FROM ranks 
          ORDER BY permission_level
        `;
        return { ranks };

      case "updateUserRank":
        if (!userId || !rankId) {
          return { error: "Gebruiker en rank zijn verplicht" };
        }

        await sql`
          UPDATE auth_users 
          SET rank_id = ${rankId}
          WHERE id = ${userId}
        `;
        return { success: true };

      default:
        return { error: "Ongeldige actie" };
    }
  } catch (err) {
    return { error: err.message };
  }
}