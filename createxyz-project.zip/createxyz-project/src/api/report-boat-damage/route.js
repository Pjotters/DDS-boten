async function handler({ boatId, description, severity }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Niet ingelogd" };
  }

  if (!boatId || !description || !severity) {
    return { error: "Missende velden" };
  }

  const damage = await sql`
    INSERT INTO boat_damages (
      boat_id,
      reported_by,
      description,
      severity
    ) VALUES (
      ${boatId},
      ${session.user.id},
      ${description},
      ${severity}
    ) RETURNING id
  `;

  await sql`
    UPDATE boats 
    SET status = 'damaged'
    WHERE id = ${boatId}
  `;

  const admins = await sql`
    SELECT email, notification_preferences 
    FROM auth_users 
    WHERE is_admin = true
  `;

  for (const admin of admins) {
    if (admin.notification_preferences?.damage_reports) {
      await fetch("https://api.sendgrid.com/v3/mail/send", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.SENDGRID_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          personalizations: [
            {
              to: [{ email: admin.email }],
            },
          ],
          from: { email: "noreply@example.com" },
          subject: `Nieuwe schademelding - Boot ${boatId}`,
          content: [
            {
              type: "text/plain",
              value: `Er is een nieuwe schademelding (${severity}) voor boot ${boatId}: ${description}`,
            },
          ],
        }),
      });
    }
  }

  return { success: true, damageId: damage[0].id };
}