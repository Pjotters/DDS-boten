async function handler({
  boatId,
  startTime,
  endTime,
  buddyUserId,
  priorityId,
  recurringPattern,
  recurringUntil,
}) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Je moet ingelogd zijn om een boot af te schrijven" };
  }

  const start = new Date(startTime);
  const end = new Date(endTime);

  if (end - start < 15 * 60 * 1000) {
    return { error: "Reservering moet minimaal 15 minuten zijn" };
  }
  if (end - start > 8 * 60 * 60 * 1000) {
    return { error: "Reservering kan maximaal 8 uur zijn" };
  }

  const roundedStart = new Date(
    Math.round(start.getTime() / (5 * 60 * 1000)) * (5 * 60 * 1000)
  );
  const roundedEnd = new Date(
    Math.round(end.getTime() / (5 * 60 * 1000)) * (5 * 60 * 1000)
  );

  const userQuery = `
    SELECT 
      u.*,
      r.permission_level,
      COUNT(res.id) as weekly_reservations
    FROM auth_users u
    LEFT JOIN ranks r ON u.rank_id = r.id
    LEFT JOIN reservations res ON 
      res.user_id = CAST(u.id AS TEXT) AND 
      res.start_time >= NOW() - INTERVAL '7 days'
    WHERE u.id = $1
    GROUP BY u.id, r.permission_level
  `;

  const users = await sql(userQuery, [session.user.id]);
  const user = users[0];

  if (user.weekly_reservations >= user.max_reservations_per_week) {
    return {
      error: "Je hebt je maximaal aantal reserveringen voor deze week bereikt",
    };
  }

  if (user.requires_buddy && buddyUserId) {
    const buddyCheck = await sql(
      "SELECT * FROM buddy_pairs WHERE novice_user_id = $1 AND experienced_user_id = $2",
      [session.user.id, buddyUserId]
    );

    if (!buddyCheck.length) {
      return { error: "Deze persoon is niet je toegewezen buddy" };
    }
  }

  if (priorityId) {
    const priority = await sql(
      "SELECT * FROM reservation_priorities WHERE id = $1",
      [priorityId]
    );

    if (priority[0]?.priority_level > 0 && !user.is_competition_team) {
      return { error: "Je hebt geen rechten voor deze prioriteit" };
    }
  }

  const bookingLimit = new Date();
  bookingLimit.setDate(bookingLimit.getDate() + user.booking_window_days);

  if (new Date(startTime) > bookingLimit) {
    return {
      error: `Je kunt maximaal ${user.booking_window_days} dagen vooruit reserveren`,
    };
  }

  const boats = await sql(
    "SELECT b.*, r.name as required_rank, r.permission_level as required_permission FROM boats b LEFT JOIN ranks r ON b.min_rank_id = r.id WHERE b.id = $1",
    [boatId]
  );

  if (!boats.length) {
    return { error: "Boot niet gevonden" };
  }

  const boat = boats[0];
  const dayOfWeek = roundedStart.toLocaleLowerCase("en-US", {
    weekday: "monday",
  });
  const availableHours = boat.available_hours[dayOfWeek];

  const isWithinAvailableHours = availableHours.some((range) => {
    const [rangeStart, rangeEnd] = range.split("-");
    const [startHour, startMinute] = rangeStart.split(":").map(Number);
    const [endHour, endMinute] = rangeEnd.split(":").map(Number);

    const rangeStartDate = new Date(roundedStart);
    rangeStartDate.setHours(startHour, startMinute, 0);

    const rangeEndDate = new Date(roundedStart);
    rangeEndDate.setHours(endHour, endMinute, 0);

    return roundedStart >= rangeStartDate && roundedEnd <= rangeEndDate;
  });

  if (!isWithinAvailableHours) {
    return { error: "Boot is niet beschikbaar op deze tijd" };
  }

  if (user.permission_level < boat.required_permission) {
    return {
      error: `Je hebt minimaal rank "${boat.required_rank}" nodig voor deze boot`,
    };
  }

  let weatherWarning = null;
  if (new Date(startTime) <= new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)) {
    const weather = await getWeatherForecast(startTime);
    if (weather.isHazardous) {
      weatherWarning = weather.warning;
    }
  }

  try {
    const result = await sql.transaction(async (txn) => {
      const buddyPairId = buddyUserId
        ? (
            await txn(
              "SELECT id FROM buddy_pairs WHERE novice_user_id = $1 AND experienced_user_id = $2",
              [session.user.id, buddyUserId]
            )
          )[0]?.id
        : null;

      const reservation = await txn(
        "INSERT INTO reservations (boat_id, user_id, start_time, end_time, status, priority_id, buddy_pair_id, weather_warning, recurring_pattern, recurring_until) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *",
        [
          boatId,
          session.user.id,
          roundedStart.toISOString(),
          roundedEnd.toISOString(),
          "active",
          priorityId || 1,
          buddyPairId,
          weatherWarning,
          recurringPattern,
          recurringUntil,
        ]
      );

      if (recurringPattern && recurringUntil) {
        const until = new Date(recurringUntil);
        let currentDate = new Date(roundedStart);
        const duration = end - start;

        while (currentDate <= until) {
          if (matchesPattern(currentDate, recurringPattern)) {
            try {
              await txn(
                "INSERT INTO reservations (boat_id, user_id, start_time, end_time, status, priority_id, buddy_pair_id, weather_warning, recurring_pattern, recurring_until) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)",
                [
                  boatId,
                  session.user.id,
                  currentDate.toISOString(),
                  new Date(currentDate.getTime() + duration).toISOString(),
                  "active",
                  priorityId || 1,
                  buddyPairId,
                  weatherWarning,
                  recurringPattern,
                  recurringUntil,
                ]
              );
            } catch (e) {
              console.log("Conflict voor herhalende reservering:", currentDate);
            }
          }
          currentDate.setDate(currentDate.getDate() + 1);
        }
      }

      return reservation[0];
    });

    return {
      success: true,
      reservation: result,
      weatherWarning,
    };
  } catch (e) {
    if (e.constraint === "no_overlapping_reservations") {
      const alternatives = await sql(
        "WITH occupied_times AS (SELECT start_time, end_time FROM reservations WHERE boat_id = $1 AND start_time::date = $2::date) SELECT generate_series($2::timestamp, $3::timestamp, '30 minutes'::interval) as potential_start, $3::timestamp - $2::timestamp as duration WHERE NOT EXISTS (SELECT 1 FROM occupied_times WHERE potential_start BETWEEN start_time AND end_time OR (potential_start + ($3::timestamp - $2::timestamp)) BETWEEN start_time AND end_time) LIMIT 3",
        [boatId, startTime, endTime]
      );

      return {
        error: "Boot is al gereserveerd op dit tijdstip",
        alternatives: alternatives.map((alt) => ({
          startTime: alt.potential_start,
          endTime: new Date(alt.potential_start.getTime() + alt.duration),
        })),
      };
    }
    throw e;
  }
}