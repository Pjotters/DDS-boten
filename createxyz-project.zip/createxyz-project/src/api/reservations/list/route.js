async function handler({
  startDate,
  endDate,
  boatId,
  boatType,
  userId,
  limit = 10,
  offset = 0,
}) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Niet ingelogd" };
  }

  let queryString = `
    SELECT 
      r.*,
      b.name as boat_name,
      b.type as boat_type,
      b.weight_class,
      u.name as user_name,
      u.email as user_email
    FROM reservations r
    JOIN boats b ON r.boat_id = b.id
    JOIN auth_users u ON r.user_id = u.id
    WHERE 1=1
  `;

  const values = [];
  let paramCount = 1;

  if (startDate) {
    queryString += ` AND r.start_time >= $${paramCount}`;
    values.push(startDate);
    paramCount++;
  }

  if (endDate) {
    queryString += ` AND r.end_time <= $${paramCount}`;
    values.push(endDate);
    paramCount++;
  }

  if (boatId) {
    queryString += ` AND r.boat_id = $${paramCount}`;
    values.push(boatId);
    paramCount++;
  }

  if (boatType) {
    queryString += ` AND b.type = $${paramCount}`;
    values.push(boatType);
    paramCount++;
  }

  const isAdminResult =
    await sql`SELECT is_admin FROM auth_users WHERE id = ${session.user.id}`;
  const isAdmin = isAdminResult[0]?.is_admin;

  if (userId && isAdmin) {
    queryString += ` AND r.user_id = $${paramCount}`;
    values.push(userId);
    paramCount++;
  } else {
    queryString += ` AND r.user_id = $${paramCount}`;
    values.push(session.user.id);
    paramCount++;
  }

  queryString += ` ORDER BY r.start_time DESC LIMIT $${paramCount} OFFSET $${
    paramCount + 1
  }`;
  values.push(limit, offset);

  const reservations = await sql(queryString, values);

  const grouped = reservations.reduce((acc, res) => {
    if (res.recurring_pattern) {
      const key = `${res.boat_id}-${res.recurring_pattern}`;
      if (!acc[key]) {
        acc[key] = {
          ...res,
          instances: [],
        };
      }
      acc[key].instances.push({
        start_time: res.start_time,
        end_time: res.end_time,
      });
    } else {
      acc[res.id] = res;
    }
    return acc;
  }, {});

  return {
    reservations: Object.values(grouped),
    total: reservations.length,
  };
}