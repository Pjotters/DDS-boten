async function handler({
  id,
  name,
  email,
  birth_date,
  phone,
  rank_id,
  maxReservationsPerWeek,
  requiresBuddy,
  isCompetitionTeam,
  bookingWindowDays,
  buddyId,
}) {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Je moet ingelogd zijn om deze actie uit te voeren" };
  }

  const admin = await sql`
    SELECT is_admin FROM auth_users WHERE id = ${session.user.id}
  `;

  if (!admin[0]?.is_admin) {
    return {
      error: "Geen toegang. Alleen administrators kunnen leden wijzigen.",
    };
  }

  if (!id) {
    return { error: "Lid ID is verplicht" };
  }

  try {
    const queries = [
      sql`
        UPDATE auth_users 
        SET 
          name = COALESCE(${name}, name),
          email = COALESCE(${email}, email),
          birth_date = COALESCE(${birth_date}, birth_date),
          phone = COALESCE(${phone}, phone),
          rank_id = COALESCE(${rank_id}, rank_id),
          max_reservations_per_week = COALESCE(${maxReservationsPerWeek}, max_reservations_per_week),
          requires_buddy = COALESCE(${requiresBuddy}, requires_buddy),
          is_competition_team = COALESCE(${isCompetitionTeam}, is_competition_team),
          booking_window_days = COALESCE(${bookingWindowDays}, booking_window_days)
        WHERE id = ${id}
      `,
    ];

    if (buddyId && requiresBuddy) {
      queries.push(sql`
        INSERT INTO buddy_pairs (novice_user_id, experienced_user_id)
        VALUES (${id}, ${buddyId})
        ON CONFLICT (novice_user_id, experienced_user_id) DO NOTHING
      `);
    }

    queries.push(sql`
      SELECT 
        u.*,
        array_agg(DISTINCT bp.experienced_user_id) as buddy_ids
      FROM auth_users u
      LEFT JOIN buddy_pairs bp ON bp.novice_user_id = u.id
      WHERE u.id = ${id}
      GROUP BY u.id
    `);

    const results = await sql.transaction(queries);
    const updatedUser = results[results.length - 1][0];

    return {
      success: true,
      message: "Lid succesvol bijgewerkt",
      user: updatedUser,
    };
  } catch (error) {
    return { error: "Er is een fout opgetreden bij het bijwerken van het lid" };
  }
}