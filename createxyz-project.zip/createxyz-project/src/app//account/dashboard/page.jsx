"use client";
import React from "react";

function MainComponent() {
  const { data: user, loading } = useUser();
  const [reservations, setReservations] = useState([]);
  const [damages, setDamages] = useState([]);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
  });
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const handlePasswordChange = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("/api/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(passwordData),
      });

      const data = await response.json();
      if (data.error) {
        setError(data.error);
        return;
      }

      setSuccess("Wachtwoord succesvol gewijzigd");
      setShowPasswordModal(false);
      setPasswordData({ currentPassword: "", newPassword: "" });
    } catch (err) {
      setError("Er is een fout opgetreden bij het wijzigen van het wachtwoord");
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="rounded-lg bg-white p-8 shadow-xl">
          <p className="text-lg text-red-600">
            Je moet ingelogd zijn om deze pagina te bekijken
          </p>
          <a
            href="/account/signin"
            className="mt-4 block rounded-lg bg-[#357AFF] px-4 py-2 text-center text-white hover:bg-[#2E69DE]"
          >
            Inloggen
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <h1 className="text-xl font-bold">RV DDS</h1>
              </div>
              <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
                <a
                  href="/afschrijfboek"
                  className="text-gray-900 inline-flex items-center px-1 pt-1 border-b-2 border-transparent hover:border-gray-300"
                >
                  Afschrijfboek
                </a>
                <a
                  href="/boot-reserveren"
                  className="text-gray-900 inline-flex items-center px-1 pt-1 border-b-2 border-transparent hover:border-gray-300"
                >
                  Boot Reserveren
                </a>
                {user.is_admin && (
                  <a
                    href="/beheer"
                    className="text-gray-900 inline-flex items-center px-1 pt-1 border-b-2 border-transparent hover:border-gray-300"
                  >
                    Beheer
                  </a>
                )}
              </div>
            </div>
            <div className="flex items-center">
              <div className="ml-3 relative">
                <button
                  onClick={() => setShowPasswordModal(true)}
                  className="text-gray-600 hover:text-gray-900 mr-4"
                >
                  <i className="fas fa-key mr-2"></i>
                  Wachtwoord
                </button>
                <a
                  href="/account/logout"
                  className="text-gray-600 hover:text-gray-900"
                >
                  Uitloggen
                </a>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {user.temp_password && (
          <div className="rounded-xl bg-yellow-50 p-4 text-yellow-800">
            <i className="fas fa-exclamation-triangle mr-2"></i>
            Je gebruikt nog een tijdelijk wachtwoord. Wijzig dit zo snel
            mogelijk.
          </div>
        )}

        <div className="px-4 py-6 sm:px-0">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <div className="bg-white overflow-hidden shadow rounded-lg">
              <div className="p-5">
                <h3 className="text-lg font-medium">Boot Reserveren</h3>
                <p className="mt-1 text-sm text-gray-600">
                  Plan een nieuwe boottocht
                </p>
                <a
                  href="/boot-reserveren"
                  className="mt-3 inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-500"
                >
                  Reserveer nu <span className="ml-1">→</span>
                </a>
              </div>
            </div>

            <div className="bg-white overflow-hidden shadow rounded-lg">
              <div className="p-5">
                <h3 className="text-lg font-medium">Afschrijfboek</h3>
                <p className="mt-1 text-sm text-gray-600">
                  Bekijk beschikbare boten
                </p>
                <a
                  href="/afschrijfboek"
                  className="mt-3 inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-500"
                >
                  Bekijk boek <span className="ml-1">→</span>
                </a>
              </div>
            </div>

            {user.is_admin && (
              <div className="bg-white overflow-hidden shadow rounded-lg">
                <div className="p-5">
                  <h3 className="text-lg font-medium">Beheer</h3>
                  <p className="mt-1 text-sm text-gray-600">
                    Beheer leden en boten
                  </p>
                  <a
                    href="/beheer"
                    className="mt-3 inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-500"
                  >
                    Ga naar beheer <span className="ml-1">→</span>
                  </a>
                </div>
              </div>
            )}
          </div>

          <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
            <div className="bg-white shadow rounded-lg p-6">
              <h2 className="text-lg font-medium mb-4">
                Recente Reserveringen
              </h2>
              {reservations.length === 0 ? (
                <p className="text-gray-600">Geen recente reserveringen</p>
              ) : (
                <div className="space-y-3">
                  {reservations.map((reservation) => (
                    <div key={reservation.id} className="rounded-lg border p-3">
                      <div className="font-medium">{reservation.boat_name}</div>
                      <div className="text-sm text-gray-600">
                        {new Date(reservation.start_time).toLocaleString()}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="bg-white shadow rounded-lg p-6">
              <h2 className />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;