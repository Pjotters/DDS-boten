"use client";
import React from "react";

function MainComponent() {
  const { data: user, loading } = useUser();
  const [members, setMembers] = useState([]);
  const [ranks, setRanks] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedRank, setSelectedRank] = useState("");
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [editingMember, setEditingMember] = useState(null);
  const [sortConfig, setSortConfig] = useState({
    key: "name",
    direction: "asc",
  });
  const [formData, setFormData] = useState({
    name: "",
    birth_date: "",
    phone: "",
    email: "",
    rank_id: "",
    temp_password: "",
    max_reservations_per_week: 5,
    booking_window_days: 14,
    requires_buddy: false,
    is_competition_team: false,
  });

  useEffect(() => {
    fetchMembers();
    fetchRanks();
  }, []);

  const fetchMembers = async () => {
    try {
      const response = await fetch("/api/get-members", { method: "POST" });
      if (!response.ok) throw new Error("Failed to fetch members");
      const data = await response.json();
      if (data.error) throw new Error(data.error);
      setMembers(data.members || []);
    } catch (err) {
      setError("Er is een fout opgetreden bij het ophalen van de leden");
      console.error(err);
    }
  };
  const fetchRanks = async () => {
    try {
      const response = await fetch("/api/get-ranks", { method: "POST" });
      if (!response.ok) throw new Error("Failed to fetch ranks");
      const data = await response.json();
      setRanks(data.ranks || []);
    } catch (err) {
      setError("Er is een fout opgetreden bij het ophalen van de ranks");
      console.error(err);
    }
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    try {
      const response = await fetch("/api/admin/create-member", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await response.json();
      if (data.error) throw new Error(data.error);

      setSuccess("Lid succesvol toegevoegd");
      setFormData({
        name: "",
        birth_date: "",
        phone: "",
        email: "",
        rank_id: "",
        temp_password: "",
      });
      fetchMembers();
    } catch (err) {
      setError(err.message);
    }
  };
  const handleEdit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    try {
      const response = await fetch("/api/update-member", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editingMember),
      });

      const data = await response.json();
      if (data.error) throw new Error(data.error);

      setSuccess("Lid succesvol bijgewerkt");
      setEditingMember(null);
      fetchMembers();
    } catch (err) {
      setError(err.message);
    }
  };
  const handleSort = (key) => {
    const direction =
      sortConfig.key === key && sortConfig.direction === "asc" ? "desc" : "asc";
    setSortConfig({ key, direction });
  };
  const sortedMembers = [...members].sort((a, b) => {
    if (sortConfig.direction === "asc") {
      return a[sortConfig.key] > b[sortConfig.key] ? 1 : -1;
    }
    return a[sortConfig.key] < b[sortConfig.key] ? 1 : -1;
  });
  const filteredMembers = sortedMembers.filter((member) => {
    const matchesSearch =
      member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      member.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRank = !selectedRank || member.rank_id === selectedRank;
    return matchesSearch && matchesRank;
  });

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  if (!user?.is_admin) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="rounded-lg bg-white p-8 shadow-xl">
          <p className="text-lg text-red-600">
            Alleen administrators hebben toegang tot deze pagina
          </p>
          <a
            href="/"
            className="mt-4 block rounded-lg bg-[#357AFF] px-4 py-2 text-center text-white hover:bg-[#2E69DE]"
          >
            Terug naar home
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="rounded-xl bg-white p-6 shadow-lg">
          <h2 className="mb-6 text-2xl font-bold">Nieuw Lid Toevoegen</h2>
          {error && (
            <div className="mb-4 rounded-lg bg-red-100 p-4 text-red-700">
              {error}
            </div>
          )}
          {success && (
            <div className="mb-4 rounded-lg bg-green-100 p-4 text-green-700">
              {success}
            </div>
          )}

          <form onSubmit={handleSubmit} className="grid gap-6 md:grid-cols-2">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Naam
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={(e) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Email
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={(e) =>
                  setFormData({ ...formData, email: e.target.value })
                }
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Geboortedatum
              </label>
              <input
                type="date"
                name="birth_date"
                value={formData.birth_date}
                onChange={(e) =>
                  setFormData({ ...formData, birth_date: e.target.value })
                }
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Telefoonnummer
              </label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={(e) =>
                  setFormData({ ...formData, phone: e.target.value })
                }
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Rank
              </label>
              <select
                name="rank_id"
                value={formData.rank_id}
                onChange={(e) =>
                  setFormData({ ...formData, rank_id: e.target.value })
                }
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none"
                required
              >
                <option value="">Selecteer een rank</option>
                {ranks.map((rank) => (
                  <option key={rank.id} value={rank.id}>
                    {rank.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Tijdelijk Wachtwoord
              </label>
              <input
                type="password"
                name="temp_password"
                value={formData.temp_password}
                onChange={(e) =>
                  setFormData({ ...formData, temp_password: e.target.value })
                }
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none"
                required
              />
            </div>
            <div className="md:col-span-2">
              <button
                type="submit"
                className="w-full rounded-lg bg-[#357AFF] px-4 py-2 text-white hover:bg-[#2E69DE]"
              >
                Lid Toevoegen
              </button>
            </div>
          </form>
        </div>

        <div className="rounded-xl bg-white p-6 shadow-lg">
          <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
            <h2 className="text-2xl font-bold">Ledenlijst</h2>
            <div className="flex flex-wrap gap-4">
              <input
                type="text"
                placeholder="Zoeken..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="rounded-lg border border-gray-300 px-4 py-2"
              />
              <select
                value={selectedRank}
                onChange={(e) => setSelectedRank(e.target.value)}
                className="rounded-lg border border-gray-300 px-4 py-2"
              >
                <option value="">Alle ranks</option>
                {ranks.map((rank) => (
                  <option key={rank.id} value={rank.id}>
                    {rank.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b text-left">
                  <th
                    className="cursor-pointer p-2"
                    onClick={() => handleSort("name")}
                  >
                    Naam{" "}
                    {sortConfig.key === "name" &&
                      (sortConfig.direction === "asc" ? "↑" : "↓")}
                  </th>
                  <th
                    className="cursor-pointer p-2"
                    onClick={() => handleSort("email")}
                  >
                    Email{" "}
                    {sortConfig.key === "email" &&
                      (sortConfig.direction === "asc" ? "↑" : "↓")}
                  </th>
                  <th className="p-2">Telefoon</th>
                  <th className="p-2">Geboortedatum</th>
                  <th className="p-2">Rank</th>
                  <th className="p-2">Acties</th>
                </tr>
              </thead>
              <tbody>
                {filteredMembers.map((member) => (
                  <tr key={member.id} className="border-b">
                    <td className="p-2">{member.name}</td>
                    <td className="p-2">{member.email}</td>
                    <td className="p-2">{member.phone}</td>
                    <td className="p-2">
                      {new Date(member.birth_date).toLocaleDateString()}
                    </td>
                    <td className="p-2">{member.rank_name}</td>
                    <td className="p-2">
                      <button
                        onClick={() => setEditingMember(member)}
                        className="mr-2 text-blue-600 hover:text-blue-800"
                      >
                        <i className="fas fa-edit"></i>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="rounded-xl bg-white p-6 shadow-lg">
          <h2 className="mb-6 text-2xl font-bold">Reserveringsinstellingen</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b text-left">
                  <th className="p-2">Naam</th>
                  <th className="p-2">Email</th>
                  <th className="p-2">Max Reserveringen</th>
                  <th className="p-2">Reserveringsperiode</th>
                  <th className="p-2">Buddy Vereist</th>
                  <th className="p-2">Wedstrijdteam</th>
                  <th className="p-2">Buddies</th>
                  <th className="p-2">Acties</th>
                </tr>
              </thead>
              <tbody>
                {filteredMembers.map((member) => (
                  <tr key={member.id} className="border-b">
                    <td className="p-2">{member.name}</td>
                    <td className="p-2">{member.email}</td>
                    <td className="p-2">
                      {member.max_reservations_per_week || 0}
                    </td>
                    <td className="p-2">
                      {member.booking_window_days || 0} dagen
                    </td>
                    <td className="p-2">
                      {member.requires_buddy ? "Ja" : "Nee"}
                    </td>
                    <td className="p-2">
                      {member.is_competition_team ? "Ja" : "Nee"}
                    </td>
                    <td className="p-2">{member.buddy_ids?.length || 0}</td>
                    <td className="p-2">
                      <button
                        onClick={() =>
                          setEditingMember({
                            ...member,
                            editingReservationSettings: true,
                          })
                        }
                        className="text-blue-600 hover:text-blue-800"
                      >
                        <i className="fas fa-cog"></i>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="rounded-xl bg-white p-6 shadow-lg">
          <h2 className="mb-6 text-2xl font-bold">Statistieken</h2>
          <div className="grid gap-6 md:grid-cols-3">
            <div className="rounded-lg bg-gray-50 p-4">
              <h3 className="mb-2 font-semibold">Actieve Buddy Koppelingen</h3>
              <p className="text-2xl font-bold">
                {members.filter((m) => m.buddy_ids?.length > 0).length}
              </p>
            </div>
            <div className="rounded-lg bg-gray-50 p-4">
              <h3 className="mb-2 font-semibold">Bijna aan Limiet</h3>
              <p className="text-2xl font-bold">
                {
                  members.filter(
                    (m) =>
                      m.max_reservations_per_week > 0 &&
                      m.weekly_reservations >= m.max_reservations_per_week - 1
                  ).length
                }
              </p>
            </div>
            <div className="rounded-lg bg-gray-50 p-4">
              <h3 className="mb-2 font-semibold">Wedstrijdteam Leden</h3>
              <p className="text-2xl font-bold">
                {members.filter((m) => m.is_competition_team).length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {editingMember && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="w-full max-w-md rounded-lg bg-white p-6">
            <h3 className="mb-4 text-xl font-bold">
              {editingMember.editingReservationSettings
                ? "Reserveringsinstellingen Bewerken"
                : "Lid Bewerken"}
            </h3>
            <form onSubmit={handleEdit}>
              <div className="space-y-4">
                {!editingMember.editingReservationSettings ? (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Naam
                      </label>
                      <input
                        type="text"
                        value={editingMember.name}
                        onChange={(e) =>
                          setEditingMember({
                            ...editingMember,
                            name: e.target.value,
                          })
                        }
                        className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Email
                      </label>
                      <input
                        type="email"
                        value={editingMember.email}
                        onChange={(e) =>
                          setEditingMember({
                            ...editingMember,
                            email: e.target.value,
                          })
                        }
                        className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Telefoon
                      </label>
                      <input
                        type="tel"
                        value={editingMember.phone}
                        onChange={(e) =>
                          setEditingMember({
                            ...editingMember,
                            phone: e.target.value,
                          })
                        }
                        className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Rank
                      </label>
                      <select
                        value={editingMember.rank_id}
                        onChange={(e) =>
                          setEditingMember({
                            ...editingMember,
                            rank_id: e.target.value,
                          })
                        }
                        className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
                        required
                      >
                        {ranks.map((rank) => (
                          <option key={rank.id} value={rank.id}>
                            {rank.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Nieuw Tijdelijk Wachtwoord (optioneel)
                      </label>
                      <input
                        type="password"
                        onChange={(e) =>
                          setEditingMember({
                            ...editingMember,
                            temp_password: e.target.value,
                          })
                        }
                        className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
                      />
                    </div>
                  </>
                ) : (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Maximum Reserveringen per Week
                      </label>
                      <input
                        type="number"
                        min="0"
                        value={editingMember.max_reservations_per_week || 0}
                        onChange={(e) =>
                          setEditingMember({
                            ...editingMember,
                            max_reservations_per_week: parseInt(e.target.value),
                          })
                        }
                        className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Reserveringsperiode (dagen)
                      </label>
                      <input
                        type="number"
                        min="1"
                        value={editingMember.booking_window_days || 14}
                        onChange={(e) =>
                          setEditingMember({
                            ...editingMember,
                            booking_window_days: parseInt(e.target.value),
                          })
                        }
                        className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="requires_buddy"
                        checked={editingMember.requires_buddy}
                        onChange={(e) =>
                          setEditingMember({
                            ...editingMember,
                            requires_buddy: e.target.checked,
                          })
                        }
                        className="h-4 w-4 rounded border-gray-300"
                      />
                      <label
                        htmlFor="requires_buddy"
                        className="text-sm font-medium text-gray-700"
                      >
                        Buddy Vereist
                      </label>
                    </div>
                    {editingMember.requires_buddy && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700">
                          Selecteer Buddy
                        </label>
                        <select
                          value={editingMember.buddyId || ""}
                          onChange={(e) =>
                            setEditingMember({
                              ...editingMember,
                              buddyId: e.target.value,
                            })
                          }
                          className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
                        >
                          <option value="">Selecteer een buddy</option>
                          {members
                            .filter(
                              (m) =>
                                m.id !== editingMember.id && !m.requires_buddy
                            )
                            .map((m) => (
                              <option key={m.id} value={m.id}>
                                {m.name}
                              </option>
                            ))}
                        </select>
                      </div>
                    )}
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="is_competition_team"
                        checked={editingMember.is_competition_team}
                        onChange={(e) =>
                          setEditingMember({
                            ...editingMember,
                            is_competition_team: e.target.checked,
                          })
                        }
                        className="h-4 w-4 rounded border-gray-300"
                      />
                      <label
                        htmlFor="is_competition_team"
                        className="text-sm font-medium text-gray-700"
                      >
                        Wedstrijdteam Lid
                      </label>
                    </div>
                  </>
                )}
              </div>
              <div className="mt-6 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setEditingMember(null)}
                  className="rounded-lg border border-gray-300 px-4 py-2 hover:bg-gray-50"
                >
                  Annuleren
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-[#357AFF] px-4 py-2 text-white hover:bg-[#2E69DE]"
                >
                  Opslaan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default MainComponent;