"use client";
import React from "react";

function MainComponent() {
  const { data: user, loading } = useUser();
  const [activeTab, setActiveTab] = useState("leden");
  const [members, setMembers] = useState([]);
  const [ranks, setRanks] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    birth_date: "",
    phone: "",
    email: "",
    rank_id: "",
    temp_password: "",
  });

  useEffect(() => {
    const fetchRanks = async () => {
      try {
        const response = await fetch("/api/get-ranks", { method: "POST" });
        if (!response.ok) {
          throw new Error("Failed to fetch ranks");
        }
        const data = await response.json();
        setRanks(data.ranks || []);
      } catch (err) {
        console.error("Error fetching ranks:", err);
        setError("Er is een fout opgetreden bij het ophalen van de ranks");
      }
    };
    fetchRanks();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("/api/create-member", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error("Failed to create member");
      }

      const data = await response.json();
      if (data.error) {
        setError(data.error);
        return;
      }

      setFormData({
        name: "",
        birth_date: "",
        phone: "",
        email: "",
        rank_id: "",
        temp_password: "",
      });

      alert("Lid succesvol toegevoegd");
    } catch (err) {
      console.error("Error creating member:", err);
      setError("Er is een fout opgetreden bij het aanmaken van het lid");
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  if (!user?.is_admin) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="rounded-lg bg-white p-8 shadow-xl">
          <p className="text-lg text-red-600">
            Alleen administrators hebben toegang tot deze pagina
          </p>
          <a
            href="/"
            className="mt-4 block rounded-lg bg-[#357AFF] px-4 py-2 text-center text-white hover:bg-[#2E69DE]"
          >
            Terug naar home
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-6">
      <div className="mx-auto max-w-6xl space-y-6">
        <div className="border-b border-gray-200 mb-6">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab("leden")}
              className={`${
                activeTab === "leden"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              Leden
            </button>
            <button
              onClick={() => setActiveTab("boten")}
              className={`${
                activeTab === "boten"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              Boten
            </button>
            <button
              onClick={() => setActiveTab("examens")}
              className={`${
                activeTab === "examens"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              Examens
            </button>
          </nav>
        </div>

        {activeTab === "leden" && (
          <>
            <div className="rounded-xl bg-white p-6 shadow-xl">
              <h2 className="mb-4 text-2xl font-bold text-gray-800">
                Nieuw Lid Toevoegen
              </h2>
              {error && (
                <div className="mb-4 rounded-lg bg-red-50 p-4 text-red-500">
                  {error}
                </div>
              )}
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Naam
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={(e) =>
                        setFormData({ ...formData, name: e.target.value })
                      }
                      className="mt-1 block w-full rounded-md border border-gray-300 p-2"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Geboortedatum
                    </label>
                    <input
                      type="date"
                      name="birth_date"
                      value={formData.birth_date}
                      onChange={(e) =>
                        setFormData({ ...formData, birth_date: e.target.value })
                      }
                      className="mt-1 block w-full rounded-md border border-gray-300 p-2"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Telefoonnummer
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData({ ...formData, phone: e.target.value })
                      }
                      className="mt-1 block w-full rounded-md border border-gray-300 p-2"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Email
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                      className="mt-1 block w-full rounded-md border border-gray-300 p-2"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Rank
                    </label>
                    <select
                      name="rank_id"
                      value={formData.rank_id}
                      onChange={(e) =>
                        setFormData({ ...formData, rank_id: e.target.value })
                      }
                      className="mt-1 block w-full rounded-md border border-gray-300 p-2"
                      required
                    >
                      <option value="">Selecteer een rank</option>
                      {ranks.map((rank) => (
                        <option key={rank.id} value={rank.id}>
                          {rank.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Tijdelijk Wachtwoord
                    </label>
                    <input
                      type="password"
                      name="temp_password"
                      value={formData.temp_password}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          temp_password: e.target.value,
                        })
                      }
                      className="mt-1 block w-full rounded-md border border-gray-300 p-2"
                      required
                    />
                  </div>
                </div>
                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="rounded-lg bg-[#357AFF] px-6 py-2 text-white hover:bg-[#2E69DE]"
                  >
                    Lid Toevoegen
                  </button>
                </div>
              </form>
            </div>
            <div className="rounded-xl bg-white p-6 shadow-xl">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-800">Ledenlijst</h2>
                <input
                  type="text"
                  placeholder="Zoeken..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="rounded-lg border border-gray-300 p-2"
                />
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b text-left">
                      <th className="p-2">Naam</th>
                      <th className="p-2">Email</th>
                      <th className="p-2">Telefoon</th>
                      <th className="p-2">Geboortedatum</th>
                      <th className="p-2">Rank</th>
                      <th className="p-2">Acties</th>
                    </tr>
                  </thead>
                  <tbody>
                    {members
                      .filter(
                        (member) =>
                          member.name
                            .toLowerCase()
                            .includes(searchTerm.toLowerCase()) ||
                          member.email
                            .toLowerCase()
                            .includes(searchTerm.toLowerCase())
                      )
                      .map((member) => (
                        <tr key={member.id} className="border-b">
                          <td className="p-2">{member.name}</td>
                          <td className="p-2">{member.email}</td>
                          <td className="p-2">{member.phone}</td>
                          <td className="p-2">
                            {new Date(member.birth_date).toLocaleDateString()}
                          </td>
                          <td className="p-2">{member.rank_name}</td>
                          <td className="p-2">
                            <button
                              className="mr-2 text-blue-600 hover:text-blue-800"
                              onClick={() => handleEdit(member)}
                            >
                              <i className="fas fa-edit"></i>
                            </button>
                            <button
                              className="text-red-600 hover:text-red-800"
                              onClick={() => handleDelete(member.id)}
                            >
                              <i className="fas fa-trash"></i>
                            </button>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}

        {activeTab === "boten" && (
          <div className="rounded-xl bg-white p-6 shadow-xl">
            <h2 className="mb-4 text-2xl font-bold text-gray-800">
              Boten Beheer
            </h2>
            <p className="text-gray-600">
              Botenbeheer functionaliteit komt hier
            </p>
          </div>
        )}

        {activeTab === "examens" && (
          <div className="rounded-xl bg-white p-6 shadow-xl">
            <h2 className="mb-4 text-2xl font-bold text-gray-800">
              Examens Beheer
            </h2>
            <p className="text-gray-600">
              Examenbeheer functionaliteit komt hier
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default MainComponent;