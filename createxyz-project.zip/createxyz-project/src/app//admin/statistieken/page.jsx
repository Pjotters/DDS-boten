"use client";
import React from "react";

function MainComponent() {
  const { data: user, loading } = useUser();
  const [error, setError] = useState(null);
  const [stats, setStats] = useState({
    total_users: 0,
    active_reservations: 0,
    open_damages: 0,
    pending_exams: 0,
    boat_usage_by_type: [],
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("/api/get-user-stats", { method: "POST" });
        if (!response.ok) {
          throw new Error("Failed to fetch stats");
        }
        const data = await response.json();

        if (data.error) {
          setError(data.error);
          return;
        }

        setStats(data);
      } catch (err) {
        console.error("Error fetching data:", err);
        setError("Er is een fout opgetreden bij het ophalen van de gegevens");
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  if (!user?.is_admin) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="rounded-lg bg-white p-8 shadow-xl">
          <p className="text-lg text-red-600">
            Alleen administrators hebben toegang tot deze pagina
          </p>
          <a
            href="/"
            className="mt-4 block rounded-lg bg-[#357AFF] px-4 py-2 text-center text-white hover:bg-[#2E69DE]"
          >
            Terug naar home
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-6">
      <div className="mx-auto max-w-7xl space-y-6">
        {error && (
          <div className="rounded-lg bg-red-50 p-4 text-red-500">{error}</div>
        )}

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-xl bg-white p-6 shadow-xl">
            <div className="flex items-center">
              <div className="rounded-full bg-blue-100 p-3">
                <i className="fas fa-users text-xl text-blue-600"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-500">Totaal aantal leden</p>
                <p className="text-2xl font-bold text-gray-800">
                  {stats.total_users}
                </p>
              </div>
            </div>
          </div>

          <div className="rounded-xl bg-white p-6 shadow-xl">
            <div className="flex items-center">
              <div className="rounded-full bg-green-100 p-3">
                <i className="fas fa-calendar-check text-xl text-green-600"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-500">Actieve reserveringen</p>
                <p className="text-2xl font-bold text-gray-800">
                  {stats.active_reservations}
                </p>
              </div>
            </div>
          </div>

          <div className="rounded-xl bg-white p-6 shadow-xl">
            <div className="flex items-center">
              <div className="rounded-full bg-red-100 p-3">
                <i className="fas fa-exclamation-triangle text-xl text-red-600"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-500">Open schademeldingen</p>
                <p className="text-2xl font-bold text-gray-800">
                  {stats.open_damages}
                </p>
              </div>
            </div>
          </div>

          <div className="rounded-xl bg-white p-6 shadow-xl">
            <div className="flex items-center">
              <div className="rounded-full bg-purple-100 p-3">
                <i className="fas fa-graduation-cap text-xl text-purple-600"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-500">Openstaande examens</p>
                <p className="text-2xl font-bold text-gray-800">
                  {stats.pending_exams}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <div className="rounded-xl bg-white p-6 shadow-xl">
            <h3 className="mb-4 text-lg font-bold text-gray-800">
              Bootgebruik per type
            </h3>
            <div className="h-64">
              {stats.boat_usage_by_type &&
              stats.boat_usage_by_type.length > 0 ? (
                <div className="space-y-4">
                  {stats.boat_usage_by_type.map((usage, index) => (
                    <div key={index} className="flex items-center">
                      <span className="w-24 text-sm text-gray-600">
                        {usage.type}
                      </span>
                      <div className="flex-1">
                        <div className="h-4 rounded-full bg-blue-100">
                          <div
                            className="h-4 rounded-full bg-blue-500"
                            style={{
                              width: `${
                                (usage.count /
                                  Math.max(
                                    ...stats.boat_usage_by_type.map(
                                      (u) => u.count
                                    )
                                  )) *
                                100
                              }%`,
                            }}
                          ></div>
                        </div>
                      </div>
                      <span className="ml-4 text-sm font-semibold">
                        {usage.count}x
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex h-full items-center justify-center text-gray-500">
                  Geen data beschikbaar
                </div>
              )}
            </div>
          </div>

          <div className="rounded-xl bg-white p-6 shadow-xl">
            <h3 className="mb-4 text-lg font-bold text-gray-800">
              Nieuwe leden per maand
            </h3>
            <div className="text-center text-gray-500">
              <i className="fas fa-chart-line mb-2 text-4xl"></i>
              <p>Grafiek wordt geladen...</p>
            </div>
          </div>

          <div className="rounded-xl bg-white p-6 shadow-xl">
            <h3 className="mb-4 text-lg font-bold text-gray-800">
              Schademeldingen trend
            </h3>
            <div className="text-center text-gray-500">
              <i className="fas fa-chart-bar mb-2 text-4xl"></i>
              <p>Grafiek wordt geladen...</p>
            </div>
          </div>

          <div className="rounded-xl bg-white p-6 shadow-xl">
            <h3 className="mb-4 text-lg font-bold text-gray-800">
              Examen slagingspercentage
            </h3>
            <div className="text-center text-gray-500">
              <i className="fas fa-chart-pie mb-2 text-4xl"></i>
              <p>Grafiek wordt geladen...</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;