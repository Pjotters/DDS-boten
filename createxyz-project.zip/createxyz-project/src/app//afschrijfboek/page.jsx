"use client";
import React from "react";

function MainComponent() {
  const { data: user, loading } = useUser();
  const [boats, setBoats] = useState([]);
  const [error, setError] = useState(null);
  const [reservations, setReservations] = useState([]);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showReservationModal, setShowReservationModal] = useState(false);
  const [showDamageModal, setShowDamageModal] = useState(false);
  const [selectedBoat, setSelectedBoat] = useState(null);
  const [selectedTimeSlot, setSelectedTimeSlot] = useState(null);
  const [filters, setFilters] = useState({ type: "", weightClass: "" });
  const [showMyReservations, setShowMyReservations] = useState(false);

  useEffect(() => {
    const fetchBoats = async () => {
      try {
        const response = await fetch("/api/get-boats", { method: "POST" });
        if (!response.ok) {
          throw new Error("Failed to fetch boats");
        }
        const data = await response.json();
        if (data.error) {
          setError(data.error);
        } else {
          setBoats(data.boats || []);
        }
      } catch (err) {
        setError("Er is een fout opgetreden bij het ophalen van de boten");
      }
    };
    fetchBoatsAndReservations();
  }, [selectedDate]);

  const fetchBoatsAndReservations = async () => {
    try {
      const boatsResponse = await fetch("/api/get-boats", { method: "POST" });
      if (!boatsResponse.ok) {
        throw new Error("Failed to fetch boats");
      }
      const boatsData = await boatsResponse.json();
      if (boatsData.error) {
        setError(boatsData.error);
        setBoats([]);
        return;
      }
      setBoats(boatsData.boats || []);
      setError(null);

      const startOfDay = new Date(selectedDate);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(selectedDate);
      endOfDay.setHours(23, 59, 59, 999);

      const reservationsResponse = await fetch("/api/get-reservations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          startDate: startOfDay.toISOString(),
          endDate: endOfDay.toISOString(),
        }),
      });
      if (!reservationsResponse.ok) {
        throw new Error("Failed to fetch reservations");
      }
      const reservationsData = await reservationsResponse.json();
      setReservations(reservationsData.reservations || []);
    } catch (err) {
      console.error("Error fetching data:", err);
      setError("Er is een fout opgetreden bij het ophalen van de gegevens");
      setBoats([]);
      setReservations([]);
    }
  };
  const handleReportDamage = async (boat) => {
    if (!user) {
      alert("Je moet ingelogd zijn om schade te melden");
      return;
    }
    setSelectedBoat(boat);
    setShowDamageModal(true);
  };
  const timeSlots = Array.from({ length: 34 }, (_, i) => {
    const hour = Math.floor(i / 2) + 6;
    const minutes = (i % 2) * 30;
    return `${hour.toString().padStart(2, "0")}:${minutes
      .toString()
      .padStart(2, "0")}`;
  });

  const filteredBoats = boats.filter((boat) => {
    if (filters.type && boat.type !== filters.type) return false;
    if (filters.weightClass && boat.weight_class !== filters.weightClass)
      return false;
    return true;
  });

  const boatTypes = [...new Set(boats.map((boat) => boat.type))];
  const weightClasses = [
    ...new Set(
      boats
        .filter((boat) => boat.weight_class !== "nvt")
        .map((boat) => boat.weight_class)
    ),
  ];

  return (
    <div className="min-h-screen bg-white">
      <div className="border-b bg-[#003366] p-4 text-white">
        <div className="mx-auto flex max-w-[1400px] flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <h1 className="font-crimson-text text-2xl font-bold">
            RV De Delftsche Sport Afschrijfboek
          </h1>
          <div className="flex flex-wrap items-center gap-4">
            <button
              onClick={() =>
                setSelectedDate(
                  new Date(selectedDate.setDate(selectedDate.getDate() - 1))
                )
              }
              className="rounded bg-white/10 px-3 py-1 hover:bg-white/20"
            >
              <i className="fas fa-chevron-left"></i>
            </button>
            <input
              type="date"
              value={selectedDate.toISOString().split("T")[0]}
              onChange={(e) => setSelectedDate(new Date(e.target.value))}
              className="rounded bg-white/10 px-3 py-1 text-white"
            />
            <button
              onClick={() =>
                setSelectedDate(
                  new Date(selectedDate.setDate(selectedDate.getDate() + 1))
                )
              }
              className="rounded bg-white/10 px-3 py-1 hover:bg-white/20"
            >
              <i className="fas fa-chevron-right"></i>
            </button>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[1400px] p-4">
        <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="flex flex-wrap gap-2">
            <select
              className="rounded-md border border-gray-300 px-3 py-1.5"
              value={filters.type}
              onChange={(e) =>
                setFilters((prev) => ({ ...prev, type: e.target.value }))
              }
            >
              <option value="">Alle types</option>
              {boatTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
            <select
              className="rounded-md border border-gray-300 px-3 py-1.5"
              value={filters.weightClass}
              onChange={(e) =>
                setFilters((prev) => ({ ...prev, weightClass: e.target.value }))
              }
            >
              <option value="">Alle gewichtsklassen</option>
              {weightClasses.map((weight) => (
                <option key={weight} value={weight}>
                  {weight}kg
                </option>
              ))}
            </select>
          </div>
          {user && (
            <button
              onClick={() => setShowMyReservations(!showMyReservations)}
              className="rounded-md bg-[#003366] px-4 py-2 text-white hover:bg-[#002244]"
            >
              {showMyReservations ? "Alle reserveringen" : "Mijn reserveringen"}
            </button>
          )}
        </div>

        {error && (
          <div className="mt-8 rounded-lg bg-red-50 p-4 text-center text-red-500">
            {error}
          </div>
        )}

        {!user && !loading ? (
          <div className="flex min-h-[calc(100vh-80px)] items-center justify-center">
            <div className="text-center">
              <h2 className="mb-4 text-2xl font-crimson-text">
                Log in om boten te kunnen reserveren
              </h2>
              <a
                href="/account/signin"
                className="inline-flex items-center rounded-lg bg-[#357AFF] px-6 py-3 text-lg font-medium text-white hover:bg-[#2E69DE]"
              >
                <i className="fas fa-sign-in-alt mr-2"></i>
                Inloggen
              </a>
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <div className="min-w-[320px] md:min-w-[768px] lg:min-w-[1200px]">
              <div className="grid grid-cols-[150px_1fr] md:grid-cols-[200px_1fr] gap-4">
                <div className="font-medium text-gray-500">Boot</div>
                <div className="grid grid-cols-12 md:grid-cols-24 lg:grid-cols-34 gap-0">
                  {timeSlots.map((time) => (
                    <div
                      key={time}
                      className="border-l px-1 text-xs text-gray-500"
                    >
                      {time.endsWith("00") ? time : ""}
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-4 space-y-2">
                {filteredBoats.map((boat) => {
                  const boatReservations = reservations.filter(
                    (r) =>
                      r.boat_id === boat.id &&
                      (!showMyReservations || r.user_id === user?.id)
                  );

                  return (
                    <div
                      key={boat.id}
                      className="grid grid-cols-[150px_1fr] md:grid-cols-[200px_1fr] gap-4"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="font-medium">{boat.name}</span>
                          <div className="text-xs text-gray-500">
                            <span>{boat.type}</span>
                            {boat.weight_class !== "nvt" && (
                              <span className="ml-2">
                                {boat.weight_class}kg
                              </span>
                            )}
                            {boat.exam_level && (
                              <span className="ml-2 rounded bg-blue-100 px-1 text-blue-800">
                                {boat.exam_level}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {boat.status !== "available" && (
                            <span
                              className={`rounded-full px-2 py-0.5 text-xs ${
                                boat.status === "damaged"
                                  ? "bg-red-100 text-red-600"
                                  : boat.status === "maintenance"
                                  ? "bg-yellow-100 text-yellow-600"
                                  : "bg-gray-100 text-gray-600"
                              }`}
                            >
                              {boat.status}
                            </span>
                          )}
                          {user && (
                            <button
                              onClick={() => handleReportDamage(boat)}
                              className="text-red-600 hover:underline"
                              title="Schade melden"
                            >
                              <i className="fas fa-exclamation-triangle"></i>
                            </button>
                          )}
                        </div>
                      </div>
                      <div className="relative grid grid-cols-12 md:grid-cols-24 lg:grid-cols-34 gap-0 rounded bg-gray-50 h-[40px]">
                        {timeSlots.map((time, index) => (
                          <div
                            key={`${boat.id}-${time}`}
                            className="relative border-l hover:bg-gray-100 h-full cursor-pointer"
                            onClick={() => {
                              if (user && boat.status === "available") {
                                setSelectedBoat(boat);
                                setSelectedTimeSlot(time);
                                setShowReservationModal(true);
                              }
                            }}
                          />
                        ))}

                        {boatReservations.map((reservation) => {
                          const start = new Date(reservation.start_time);
                          const end = new Date(reservation.end_time);
                          const startSlot =
                            (start.getHours() - 6) * 2 +
                            Math.floor(start.getMinutes() / 30);
                          const endSlot =
                            (end.getHours() - 6) * 2 +
                            Math.floor(end.getMinutes() / 30);
                          const duration = endSlot - startSlot;

                          return (
                            <div
                              key={reservation.id}
                              className="absolute top-0 flex items-center rounded px-2 py-1 text-xs text-white"
                              style={{
                                left: `${(startSlot / 34) * 100}%`,
                                width: `${(duration / 34) * 100}%`,
                                height: "36px",
                                backgroundColor:
                                  reservation.user_id === user?.id
                                    ? "#357AFF"
                                    : "#22C55E",
                                marginTop: "2px",
                              }}
                              title={`${
                                reservation.user_name
                              }: ${start.toLocaleTimeString()} - ${end.toLocaleTimeString()}`}
                            >
                              <span className="overflow-hidden text-ellipsis whitespace-nowrap">
                                {reservation.user_name}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {showReservationModal && selectedBoat && (
          <ReservationModal
            boat={selectedBoat}
            initialTime={selectedTimeSlot}
            selectedDate={selectedDate}
            onClose={() => setShowReservationModal(false)}
            onSubmit={async (startTime, endTime) => {
              try {
                const response = await fetch("/api/create-reservation", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    boatId: selectedBoat.id,
                    startTime: startTime.toISOString(),
                    endTime: endTime.toISOString(),
                  }),
                });
                if (!response.ok) {
                  throw new Error("Failed to create reservation");
                }
                setShowReservationModal(false);
                fetchBoatsAndReservations();
              } catch (error) {
                alert("Er ging iets mis bij het maken van de reservering");
              }
            }}
          />
        )}

        {showDamageModal && selectedBoat && (
          <DamageReportModal
            boat={selectedBoat}
            onClose={() => setShowDamageModal(false)}
            onSubmit={async (description, severity) => {
              try {
                const response = await fetch("/api/manage-boat-damages", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    action: "report",
                    boatId: selectedBoat.id,
                    description,
                    severity,
                  }),
                });
                if (!response.ok) {
                  throw new Error("Failed to report damage");
                }
                setShowDamageModal(false);
                fetchBoatsAndReservations();
              } catch (error) {
                alert("Er ging iets mis bij het melden van de schade");
              }
            }}
          />
        )}
      </div>
    </div>
  );
}

function ReservationModal({
  boat,
  initialTime,
  selectedDate,
  onClose,
  onSubmit,
}) {
  const [startTime, setStartTime] = useState(initialTime || "");
  const [duration, setDuration] = useState(2);

  const handleSubmit = () => {
    const [hours, minutes] = startTime.split(":");
    const start = new Date(selectedDate);
    start.setHours(parseInt(hours), parseInt(minutes), 0, 0);

    const end = new Date(start);
    end.setHours(start.getHours() + Math.floor(duration));
    end.setMinutes(start.getMinutes() + (duration % 1) * 60);

    onSubmit(start, end);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="w-full max-w-md rounded-lg bg-white p-6">
        <h2 className="mb-4 text-xl font-bold">Reserveer {boat.name}</h2>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Starttijd
            </label>
            <input
              type="time"
              value={startTime}
              onChange={(e) => setStartTime(e.target.value)}
              className="mt-1 block w-full rounded-md border border-gray-300 p-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Duur (uren)
            </label>
            <input
              type="number"
              value={duration}
              onChange={(e) => setDuration(parseFloat(e.target.value))}
              min="0.5"
              max="4"
              step="0.5"
              className="mt-1 block w-full rounded-md border border-gray-300 p-2"
            />
          </div>
          <div className="flex justify-end gap-2">
            <button
              onClick={onClose}
              className="rounded-md border border-gray-300 px-4 py-2 hover:bg-gray-50"
            >
              Annuleren
            </button>
            <button
              onClick={handleSubmit}
              className="rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
            >
              Reserveren
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function DamageReportModal({ boat, onClose, onSubmit }) {
  const [description, setDescription] = useState("");
  const [severity, setSeverity] = useState("medium");

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex min-h-screen items-end justify-center px-4 pb-20 pt-4 text-center sm:block sm:p-0">
        <div className="fixed inset-0 transition-opacity" aria-hidden="true">
          <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>
        <div className="inline-block transform overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left align-bottom shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg sm:p-6 sm:align-middle">
          <div>
            <h3 className="text-lg font-medium leading-6 text-gray-900">
              Schade melden voor {boat.name}
            </h3>
            <div className="mt-2">
              <textarea
                className="w-full rounded-md border border-gray-300 p-2"
                rows="4"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Beschrijf de schade..."
              ></textarea>
              <select
                className="mt-2 w-full rounded-md border border-gray-300 p-2"
                value={severity}
                onChange={(e) => setSeverity(e.target.value)}
              >
                <option value="low">Laag - Klein probleem</option>
                <option value="medium">Medium - Moet gerepareerd worden</option>
                <option value="high">
                  Hoog - Boot kan niet gebruikt worden
                </option>
                <option value="critical">Kritiek - Direct actie nodig</option>
              </select>
            </div>
          </div>
          <div className="mt-5 sm:mt-6">
            <button
              type="button"
              className="inline-flex w-full justify-center rounded-md border border-transparent bg-red-600 px-4 py-2 text-base font-medium text-white shadow-sm hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 sm:text-sm"
              onClick={() => onSubmit(description, severity)}
            >
              Schade melden
            </button>
            <button
              type="button"
              className="mt-2 inline-flex w-full justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-base font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 sm:text-sm"
              onClick={onClose}
            >
              Annuleren
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;