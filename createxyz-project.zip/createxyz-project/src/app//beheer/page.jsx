"use client";
import React from "react";

function MainComponent() {
  const [activeTab, setActiveTab] = useState("boats");
  const { data: user, loading: userLoading } = useUser();
  const [boats, setBoats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchBoats = async () => {
      try {
        const response = await fetch("/api/get-boats", { method: "POST" });
        if (!response.ok) {
          throw new Error("Failed to fetch boats");
        }
        const data = await response.json();
        if (data.error) {
          throw new Error(data.error);
        }
        setBoats(data.boats);
      } catch (err) {
        setError(err.message);
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchBoats();
  }, []);

  if (userLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="rounded-lg bg-white p-8 shadow-xl">
          <p className="text-lg">
            Je moet ingelogd zijn om deze pagina te bekijken
          </p>
          <a
            href="/account/signin?callbackUrl=/admin"
            className="mt-4 block rounded-lg bg-[#357AFF] px-4 py-2 text-center text-white hover:bg-[#2E69DE]"
          >
            Inloggen
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-6">
      <div className="mx-auto max-w-6xl rounded-xl bg-white p-6 shadow-xl">
        <h1 className="mb-6 text-3xl font-bold text-gray-800">
          Beheerdersdashboard
        </h1>

        <div className="mb-6 flex space-x-4 border-b">
          <button
            onClick={() => setActiveTab("boats")}
            className={`pb-2 ${
              activeTab === "boats"
                ? "border-b-2 border-[#357AFF] text-[#357AFF]"
                : "text-gray-600"
            }`}
          >
            Boten Beheer
          </button>
          <button
            onClick={() => setActiveTab("members")}
            className={`pb-2 ${
              activeTab === "members"
                ? "border-b-2 border-[#357AFF] text-[#357AFF]"
                : "text-gray-600"
            }`}
          >
            Leden Beheer
          </button>
          <button
            onClick={() => setActiveTab("reservations")}
            className={`pb-2 ${
              activeTab === "reservations"
                ? "border-b-2 border-[#357AFF] text-[#357AFF]"
                : "text-gray-600"
            }`}
          >
            Reserveringen
          </button>
        </div>

        {activeTab === "boats" && (
          <div>
            <div className="mb-4 flex justify-between">
              <h2 className="text-xl font-semibold">Boten</h2>
              <button className="rounded-lg bg-[#357AFF] px-4 py-2 text-white hover:bg-[#2E69DE]">
                Nieuwe Boot Toevoegen
              </button>
            </div>

            {loading ? (
              <div>Loading boats...</div>
            ) : error ? (
              <div className="rounded-lg bg-red-50 p-4 text-red-500">
                {error}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b text-left">
                      <th className="pb-2">Naam</th>
                      <th className="pb-2">Type</th>
                      <th className="pb-2">Status</th>
                      <th className="pb-2">Acties</th>
                    </tr>
                  </thead>
                  <tbody>
                    {boats.map((boat) => (
                      <tr key={boat.id} className="border-b">
                        <td className="py-2">{boat.name}</td>
                        <td className="py-2">{boat.type}</td>
                        <td className="py-2">{boat.status}</td>
                        <td className="py-2">
                          <button className="mr-2 text-[#357AFF] hover:text-[#2E69DE]">
                            <i className="fas fa-edit"></i>
                          </button>
                          <button className="text-red-500 hover:text-red-600">
                            <i className="fas fa-trash"></i>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {activeTab === "members" && (
          <div>
            <h2 className="text-xl font-semibold">Leden Beheer</h2>
            <p className="mt-4 text-gray-600">
              Leden beheerfunctionaliteit komt binnenkort beschikbaar.
            </p>
          </div>
        )}

        {activeTab === "reservations" && (
          <div>
            <h2 className="text-xl font-semibold">Reserveringen</h2>
            <p className="mt-4 text-gray-600">
              Reserveringen beheerfunctionaliteit komt binnenkort beschikbaar.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default MainComponent;