"use client";
import React from "react";

function MainComponent() {
  const [boats, setBoats] = useState([]);
  const [selectedBoat, setSelectedBoat] = useState(null);
  const [date, setDate] = useState(new Date());
  const [startTime, setStartTime] = useState("");
  const [duration, setDuration] = useState(2);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [reservations, setReservations] = useState([]);
  const { data: user } = useUser();

  useEffect(() => {
    const fetchBoats = async () => {
      try {
        const response = await fetch("/api/get-boats", { method: "POST" });
        if (!response.ok) {
          throw new Error("Kon boten niet ophalen");
        }
        const data = await response.json();
        if (data.error) {
          setError(data.error);
        } else {
          setBoats(data.boats);
          if (data.boats.length > 0) {
            const boatId = new URLSearchParams(window.location.search).get(
              "boat"
            );
            if (boatId) {
              const selectedBoat = data.boats.find((b) => b.id === boatId);
              if (selectedBoat) {
                setSelectedBoat(selectedBoat);
                fetchReservations(boatId);
              }
            }
          }
        }
      } catch (err) {
        setError("Er is iets misgegaan bij het ophalen van de boten");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    const fetchReservations = async (boatId) => {
      try {
        const response = await fetch("/api/get-reservations", {
          method: "POST",
          body: JSON.stringify({ boatId }),
        });
        if (!response.ok) {
          throw new Error("Kon reserveringen niet ophalen");
        }
        const data = await response.json();
        if (data.error) {
          setError(data.error);
        } else {
          setReservations(data.reservations || []);
        }
      } catch (err) {
        setError("Er is iets misgegaan bij het ophalen van de reserveringen");
        console.error(err);
      }
    };

    fetchBoats();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    if (!selectedBoat) {
      setError("Selecteer een boot");
      return;
    }

    if (!date || !startTime || !duration) {
      setError("Vul alle verplichte velden in");
      return;
    }

    const startDateTime = new Date(date);
    startDateTime.setHours(parseInt(startTime.split(":")[0]));
    startDateTime.setMinutes(parseInt(startTime.split(":")[1]));

    const endDateTime = new Date(startDateTime);
    endDateTime.setHours(startDateTime.getHours() + duration);

    if (startDateTime < new Date()) {
      setError("Je kunt niet in het verleden reserveren");
      return;
    }

    try {
      const response = await fetch("/api/create-reservation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          boatId: selectedBoat.id,
          startTime: startDateTime.toISOString(),
          endTime: endDateTime.toISOString(),
        }),
      });

      if (!response.ok) {
        throw new Error("Kon reservering niet maken");
      }

      const data = await response.json();
      if (data.error) {
        setError(data.error);
      } else {
        fetchReservations(selectedBoat.id);
        alert("Reservering succesvol gemaakt!");
      }
    } catch (err) {
      setError("Er is iets misgegaan bij het maken van de reservering");
      console.error(err);
    }
  };

  const handleCancelReservation = async (reservationId) => {
    try {
      const response = await fetch("/api/cancel-reservation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reservationId }),
      });

      if (!response.ok) {
        throw new Error("Kon reservering niet annuleren");
      }

      const data = await response.json();
      if (data.error) {
        setError(data.error);
      } else {
        fetchReservations(selectedBoat.id);
        alert("Reservering succesvol geannuleerd!");
      }
    } catch (err) {
      setError("Er is iets misgegaan bij het annuleren van de reservering");
      console.error(err);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="text-lg">Laden...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50 p-4">
        <div className="w-full max-w-md rounded-2xl bg-white p-8 text-center shadow-xl">
          <h1 className="mb-4 text-2xl font-bold text-gray-800">
            Je moet ingelogd zijn om te reserveren
          </h1>
          <a
            href="/account/signin"
            className="text-[#357AFF] hover:text-[#2E69DE]"
          >
            Klik hier om in te loggen
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4">
      <div className="mx-auto max-w-4xl">
        <div className="mb-8 rounded-2xl bg-white p-8 shadow-xl">
          <h1 className="mb-6 text-3xl font-bold text-gray-800">
            Boot Reserveren
          </h1>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">
                Boot selecteren
              </label>
              <select
                value={selectedBoat?.id || ""}
                onChange={(e) => {
                  const boat = boats.find((b) => b.id === e.target.value);
                  setSelectedBoat(boat);
                  if (boat) {
                    fetchReservations(boat.id);
                  }
                }}
                className="w-full rounded-lg border border-gray-200 p-3 text-lg outline-none focus:border-[#357AFF] focus:ring-1 focus:ring-[#357AFF]"
              >
                <option value="">Selecteer een boot</option>
                {boats.map((boat) => (
                  <option key={boat.id} value={boat.id}>
                    {boat.name}{" "}
                    {boat.status !== "available"
                      ? `(${
                          boat.status === "maintenance"
                            ? "in onderhoud"
                            : "beschadigd"
                        })`
                      : ""}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">
                Datum
              </label>
              <input
                type="date"
                value={date.toISOString().split("T")[0]}
                onChange={(e) => setDate(new Date(e.target.value))}
                min={new Date().toISOString().split("T")[0]}
                max={
                  new Date(
                    Date.now() +
                      (user.booking_window_days || 7) * 24 * 60 * 60 * 1000
                  )
                    .toISOString()
                    .split("T")[0]
                }
                className="w-full rounded-lg border border-gray-200 p-3 text-lg outline-none focus:border-[#357AFF] focus:ring-1 focus:ring-[#357AFF]"
              />
            </div>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Starttijd
                </label>
                <input
                  type="time"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  className="w-full rounded-lg border border-gray-200 p-3 text-lg outline-none focus:border-[#357AFF] focus:ring-1 focus:ring-[#357AFF]"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Duur (uren)
                </label>
                <input
                  type="number"
                  value={duration}
                  onChange={(e) => setDuration(parseInt(e.target.value))}
                  min="1"
                  max="8"
                  className="w-full rounded-lg border border-gray-200 p-3 text-lg outline-none focus:border-[#357AFF] focus:ring-1 focus:ring-[#357AFF]"
                />
              </div>
            </div>

            {error && (
              <div className="rounded-lg bg-red-50 p-3 text-sm text-red-500">
                {error}
              </div>
            )}

            <button
              type="submit"
              className="w-full rounded-lg bg-[#357AFF] px-4 py-3 text-base font-medium text-white transition-colors hover:bg-[#2E69DE] focus:outline-none focus:ring-2 focus:ring-[#357AFF] focus:ring-offset-2"
            >
              Reservering Bevestigen
            </button>
          </form>
        </div>

        <div className="rounded-2xl bg-white p-8 shadow-xl">
          <h2 className="mb-6 text-2xl font-bold text-gray-800">
            Reserveringen
          </h2>
          {reservations.length > 0 ? (
            <div className="space-y-4">
              {reservations.map((reservation) => (
                <div key={reservation.id} className="rounded-lg bg-gray-50 p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">
                        {new Date(reservation.start_time).toLocaleString()}
                      </p>
                      <p className="text-sm text-gray-600">
                        tot {new Date(reservation.end_time).toLocaleString()}
                      </p>
                      <p className="text-sm text-gray-600">
                        Door: {reservation.user_name}
                      </p>
                    </div>
                    {(user?.id === reservation.user_id ||
                      user?.rank_id >= 80) && (
                      <button
                        onClick={() => handleCancelReservation(reservation.id)}
                        className="rounded bg-red-600 px-4 py-2 text-white hover:bg-red-700"
                      >
                        Annuleren
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-gray-600">Nog geen reserveringen gevonden</div>
          )}
        </div>
      </div>
    </div>
  );
}

export default MainComponent;