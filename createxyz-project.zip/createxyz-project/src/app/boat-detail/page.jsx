"use client";
import React from "react";

function MainComponent() {
  const { data: user } = useUser();
  const [boat, setBoat] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showDamageForm, setShowDamageForm] = useState(false);
  const [damageDescription, setDamageDescription] = useState("");
  const [damageSeverity, setDamageSeverity] = useState("low");
  const { id } = useParams();

  useEffect(() => {
    const fetchBoatDetails = async () => {
      try {
        const response = await fetch("/api/get-boats", {
          method: "POST",
          body: JSON.stringify({ boatId: id }),
        });

        if (!response.ok) {
          throw new Error("Boot niet gevonden");
        }

        const data = await response.json();
        setBoat(data.boat);
      } catch (err) {
        setError("Er is een fout opgetreden bij het laden van de boot details");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchBoatDetails();
  }, [id]);

  const handleDamageReport = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("/api/report-boat-damage", {
        method: "POST",
        body: JSON.stringify({
          boatId: id,
          description: damageDescription,
          severity: damageSeverity,
        }),
      });

      if (!response.ok) {
        throw new Error("Kon schade niet melden");
      }

      setShowDamageForm(false);
      setDamageDescription("");
      setDamageSeverity("low");
      window.location.reload();
    } catch (err) {
      setError("Er is een fout opgetreden bij het melden van schade");
      console.error(err);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-2xl text-gray-600">
          <i className="fas fa-spinner fa-spin mr-2"></i>
          Laden...
        </div>
      </div>
    );
  }

  if (error || !boat) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-2xl text-red-600">
          <i className="fas fa-exclamation-circle mr-2"></i>
          {error || "Boot niet gevonden"}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="relative h-96">
            <img
              src={boat.image || "/images/default-boat.jpg"}
              alt={`${boat.name} boot`}
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-6">
              <h1 className="text-4xl font-crimson-text text-white font-bold">
                {boat.name}
              </h1>
              <p className="text-white mt-2">{boat.type}</p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 p-6">
            <div className="md:col-span-2">
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-crimson-text font-bold text-gray-900">
                    Technische Specificaties
                  </h2>
                  <div className="mt-4 grid grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <p className="text-sm text-gray-600">Lengte</p>
                      <p className="text-lg font-semibold">{boat.length}m</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <p className="text-sm text-gray-600">Gewicht</p>
                      <p className="text-lg font-semibold">{boat.weight}kg</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <p className="text-sm text-gray-600">Bouwjaar</p>
                      <p className="text-lg font-semibold">{boat.year}</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <p className="text-sm text-gray-600">Rigger type</p>
                      <p className="text-lg font-semibold">{boat.riggerType}</p>
                    </div>
                  </div>
                </div>

                {user && (
                  <div className="flex space-x-4">
                    <a
                      href={`/afschrijfboek?boat=${id}`}
                      className="bg-[#357AFF] text-white px-6 py-3 rounded-lg hover:bg-[#2E69DE] transition flex items-center"
                    >
                      <i className="fas fa-calendar-plus mr-2"></i>
                      Boot afschrijven
                    </a>
                    <button
                      onClick={() => setShowDamageForm(true)}
                      className="bg-red-500 text-white px-6 py-3 rounded-lg hover:bg-red-600 transition flex items-center"
                    >
                      <i className="fas fa-exclamation-triangle mr-2"></i>
                      Schade melden
                    </button>
                  </div>
                )}

                {showDamageForm && (
                  <div className="mt-6 bg-gray-50 p-6 rounded-lg">
                    <h3 className="text-xl font-bold mb-4">Schade melden</h3>
                    <form onSubmit={handleDamageReport}>
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700">
                            Beschrijving
                          </label>
                          <textarea
                            value={damageDescription}
                            onChange={(e) =>
                              setDamageDescription(e.target.value)
                            }
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                            rows="4"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700">
                            Ernst
                          </label>
                          <select
                            value={damageSeverity}
                            onChange={(e) => setDamageSeverity(e.target.value)}
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                          >
                            <option value="low">Laag</option>
                            <option value="medium">Gemiddeld</option>
                            <option value="high">Hoog</option>
                          </select>
                        </div>
                        <div className="flex space-x-4">
                          <button
                            type="submit"
                            className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600"
                          >
                            Melden
                          </button>
                          <button
                            type="button"
                            onClick={() => setShowDamageForm(false)}
                            className="bg-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-400"
                          >
                            Annuleren
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                )}

                <div>
                  <h2 className="text-2xl font-crimson-text font-bold text-gray-900">
                    Geschiedenis
                  </h2>
                  <div className="mt-4 space-y-4">
                    {boat.history?.map((item, index) => (
                      <div key={index} className="bg-gray-50 p-4 rounded-lg">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="font-semibold">{item.type}</p>
                            <p className="text-sm text-gray-600">
                              {item.description}
                            </p>
                          </div>
                          <p className="text-sm text-gray-500">{item.date}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div>
              <div className="bg-gray-50 p-6 rounded-lg">
                <h2 className="text-xl font-bold mb-4">Status</h2>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-600">Huidige status</p>
                    <p
                      className={`text-lg font-semibold ${
                        boat.status === "available"
                          ? "text-green-600"
                          : boat.status === "maintenance"
                          ? "text-orange-600"
                          : "text-red-600"
                      }`}
                    >
                      {boat.status === "available"
                        ? "Beschikbaar"
                        : boat.status === "maintenance"
                        ? "In onderhoud"
                        : "Niet beschikbaar"}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Vereiste rank</p>
                    <p className="text-lg font-semibold">{boat.requiredRank}</p>
                  </div>
                </div>
              </div>

              {user?.is_admin && (
                <div className="mt-6 bg-gray-50 p-6 rounded-lg">
                  <h2 className="text-xl font-bold mb-4">Admin Opties</h2>
                  <div className="space-y-4">
                    <button className="w-full bg-[#357AFF] text-white px-4 py-2 rounded-lg hover:bg-[#2E69DE] transition flex items-center justify-center">
                      <i className="fas fa-edit mr-2"></i>
                      Boot bewerken
                    </button>
                    <button className="w-full bg-orange-500 text-white px-4 py-2 rounded-lg hover:bg-orange-600 transition flex items-center justify-center">
                      <i className="fas fa-tools mr-2"></i>
                      Onderhoud plannen
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;