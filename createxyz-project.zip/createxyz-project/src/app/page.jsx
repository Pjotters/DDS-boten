"use client";
import React from "react";

function MainComponent() {
  const { data: user } = useUser();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [availableBoats, setAvailableBoats] = useState(0);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const fetchBoats = async () => {
      try {
        const response = await fetch("/api/get-reservations", {
          method: "POST",
          body: JSON.stringify({
            startDate: new Date().toISOString(),
            endDate: new Date().toISOString(),
          }),
        });
        if (!response.ok) {
          throw new Error("Failed to fetch boats");
        }
        const data = await response.json();
        const available = 25 - (data.reservations?.length || 0);
        setAvailableBoats(available);
      } catch (error) {
        console.error("Error fetching boats:", error);
      }
    };

    fetchBoats();

    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <header className="bg-white shadow-md fixed w-full z-50">
        <div className="mx-auto max-w-7xl px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <a href="/" className="flex items-center space-x-3">
                <img
                  src="/images/logo.png"
                  alt="RV DDS Logo"
                  className="h-12"
                />
                <div>
                  <h1 className="text-xl font-bold text-gray-900">RV DDS</h1>
                  <p className="text-sm text-gray-600">De Delftsche Sport</p>
                </div>
              </a>
              <div className="ml-4 px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-600 hidden md:flex items-center">
                <i className="fas fa-map-marker-alt mr-2 text-[#357AFF]"></i>
                Delft
              </div>
              <nav className="ml-8 hidden md:block">
                <ul className="flex space-x-6">
                  <li>
                    <a
                      href="/"
                      className="text-gray-700 hover:text-[#357AFF] font-medium"
                    >
                      Home
                    </a>
                  </li>
                  <li>
                    <a
                      href="/afschrijfboek"
                      className="text-gray-700 hover:text-[#357AFF] font-medium"
                    >
                      Afschrijfboek
                    </a>
                  </li>
                  <li>
                    <a
                      href="/over-ons"
                      className="text-gray-700 hover:text-[#357AFF] font-medium"
                    >
                      Over ons
                    </a>
                  </li>
                </ul>
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              {user ? (
                <div className="relative" ref={dropdownRef}>
                  <button
                    onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                    className="flex items-center space-x-2 text-gray-700 hover:text-[#357AFF]"
                  >
                    <div className="w-10 h-10 rounded-full bg-[#357AFF] text-white flex items-center justify-center">
                      {user.name?.charAt(0).toUpperCase()}
                    </div>
                  </button>
                  {isDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2">
                      <a
                        href="/dashboard"
                        className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                      >
                        <i className="fas fa-tachometer-alt mr-2"></i>Dashboard
                      </a>
                      <a
                        href="/mijn-reserveringen"
                        className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                      >
                        <i className="fas fa-calendar mr-2"></i>Mijn
                        reserveringen
                      </a>
                      {user.is_admin && (
                        <a
                          href="/beheer"
                          className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                        >
                          <i className="fas fa-cog mr-2"></i>Admin paneel
                        </a>
                      )}
                      <hr className="my-2" />
                      <a
                        href="/account/logout"
                        className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                      >
                        <i className="fas fa-sign-out-alt mr-2"></i>Uitloggen
                      </a>
                    </div>
                  )}
                </div>
              ) : (
                <a
                  href="/account/signin"
                  className="rounded-lg bg-[#357AFF] px-4 py-2 text-white hover:bg-[#2E69DE]"
                >
                  <i className="fas fa-sign-in-alt mr-2"></i>Inloggen
                </a>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="relative h-[600px] overflow-hidden pt-20">
        <img
          src="/images/rowing-hero.jpg"
          alt="Roeiers op het water tijdens zonsondergang"
          className="absolute h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            {user ? (
              <h1 className="font-crimson-text text-5xl font-bold">
                Welkom terug bij RV DDS, {user.name}!
              </h1>
            ) : (
              <h1 className="font-crimson-text text-5xl font-bold">
                Welkom bij RV DDS
              </h1>
            )}
            <p className="mt-4 text-xl">
              Dé studentenroeivereniging van Delft sinds 1885
            </p>
            <div className="mt-8 flex flex-col items-center space-y-4">
              <a
                href="/afschrijfboek"
                className="inline-flex items-center rounded-lg bg-[#357AFF] px-6 py-3 text-lg font-medium text-white transition hover:bg-[#2E69DE] w-full md:w-auto justify-center"
              >
                <i className="fas fa-book mr-2"></i>
                Naar afschrijfboek
              </a>
              <div className="text-lg">
                <i className="fas fa-ship mr-2"></i>
                Momenteel {availableBoats} boten beschikbaar
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-16 flex-grow">
        {user?.is_admin && (
          <div className="mb-16">
            <h2 className="font-crimson-text text-3xl font-bold text-gray-900 mb-6">
              Admin Dashboard
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <a
                href="/ledenbeheer"
                className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition"
              >
                <i className="fas fa-users text-[#357AFF] text-3xl mb-4"></i>
                <h3 className="text-xl font-bold mb-2">Ledenbeheer</h3>
                <p className="text-gray-600">
                  Beheer alle leden van de vereniging
                </p>
              </a>
              <a
                href="/bootbeheer"
                className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition"
              >
                <i className="fas fa-ship text-[#357AFF] text-3xl mb-4"></i>
                <h3 className="text-xl font-bold mb-2">Bootbeheer</h3>
                <p className="text-gray-600">Beheer de vloot en onderhoud</p>
              </a>
              <a
                href="/statistieken"
                className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition"
              >
                <i className="fas fa-chart-bar text-[#357AFF] text-3xl mb-4"></i>
                <h3 className="text-xl font-bold mb-2">Statistieken</h3>
                <p className="text-gray-600">Bekijk verenigingsstatistieken</p>
              </a>
            </div>
          </div>
        )}
        <div className="grid gap-16 md:grid-cols-2">
          <div>
            <h2 className="font-crimson-text text-3xl font-bold text-gray-900">
              Over onze vereniging
            </h2>
            <p className="mt-4 text-lg text-gray-600">
              RV De Delftsche Sport is een bruisende studentenroeivereniging in
              het hart van Delft. Met een rijke historie die teruggaat tot 1885,
              bieden wij onze leden de perfecte combinatie van sportieve
              uitdaging en gezelligheid.
            </p>
            <div className="mt-8 grid grid-cols-2 gap-4">
              <div className="rounded-lg bg-gray-50 p-4 text-center">
                <div className="text-3xl font-bold text-[#357AFF]">100+</div>
                <div className="mt-2 text-gray-600">Actieve leden</div>
              </div>
              <div className="rounded-lg bg-gray-50 p-4 text-center">
                <div className="text-3xl font-bold text-[#357AFF]">25+</div>
                <div className="mt-2 text-gray-600">Boten</div>
              </div>
            </div>
          </div>
          <div className="grid gap-4">
            <img
              src="/images/rowing-training.jpg"
              alt="Roeiers tijdens training op het water"
              className="h-[300px] w-full rounded-lg object-cover"
            />
          </div>
        </div>

        <div className="mt-16 grid gap-8 md:grid-cols-2">
          <div>
            <h2 className="font-crimson-text text-3xl font-bold text-gray-900 mb-6">
              Laatste nieuws & Mededelingen
            </h2>
            <div className="space-y-6">
              <div className="rounded-lg bg-white p-6 shadow-lg border-l-4 border-[#357AFF]">
                <div className="text-sm text-gray-500">15 maart 2025</div>
                <h3 className="mt-2 text-xl font-bold text-gray-900">
                  Succesvolle Head of the River
                </h3>
                <p className="mt-2 text-gray-600">
                  Onze teams hebben uitstekend gepresteerd tijdens de jaarlijkse
                  Head of the River. Lees hier meer over de resultaten.
                </p>
              </div>
              <div className="rounded-lg bg-white p-6 shadow-lg border-l-4 border-red-500">
                <div className="flex items-center">
                  <i className="fas fa-exclamation-triangle text-red-500 mr-2"></i>
                  <div className="text-sm font-semibold text-red-500">
                    Belangrijke mededeling
                  </div>
                </div>
                <h3 className="mt-2 text-xl font-bold text-gray-900">
                  Onderhoud vlot 3
                </h3>
                <p className="mt-2 text-gray-600">
                  Vlot 3 is tijdelijk niet beschikbaar vanwege gepland
                  onderhoud.
                </p>
              </div>
            </div>
          </div>
          <div>
            <h2 className="font-crimson-text text-3xl font-bold text-gray-900 mb-6">
              Quick Links & Status
            </h2>
            <div className="grid gap-4">
              <div className="rounded-lg bg-gray-50 p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  Veelgebruikte functies
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <a
                    href="/afschrijfboek"
                    className="flex items-center p-3 bg-white rounded-lg shadow hover:shadow-md transition"
                  >
                    <i className="fas fa-book text-[#357AFF] mr-2"></i>
                    <span>Afschrijfboek</span>
                  </a>
                  <a
                    href="/mijn-reserveringen"
                    className="flex items-center p-3 bg-white rounded-lg shadow hover:shadow-md transition"
                  >
                    <i className="fas fa-calendar text-[#357AFF] mr-2"></i>
                    <span>Mijn reserveringen</span>
                  </a>
                  <a
                    href="/schades-melden"
                    className="flex items-center p-3 bg-white rounded-lg shadow hover:shadow-md transition"
                  >
                    <i className="fas fa-exclamation-circle text-[#357AFF] mr-2"></i>
                    <span>Schade melden</span>
                  </a>
                  <a
                    href="/contact"
                    className="flex items-center p-3 bg-white rounded-lg shadow hover:shadow-md transition"
                  >
                    <i className="fas fa-envelope text-[#357AFF] mr-2"></i>
                    <span>Contact</span>
                  </a>
                </div>
              </div>
              <div className="rounded-lg bg-gray-50 p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  Status overzicht
                </h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <i className="fas fa-cloud-sun text-[#357AFF] mr-2"></i>
                      <span>Weer</span>
                    </div>
                    <span>12°C, Lichte bries</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <i className="fas fa-water text-[#357AFF] mr-2"></i>
                      <span>Waterstand</span>
                    </div>
                    <span>+0.4m NAP</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <footer className="bg-gray-900 text-white mt-16">
        <div className="mx-auto max-w-7xl px-4 py-12">
          <div className="grid gap-8 md:grid-cols-4">
            <div>
              <h3 className="font-crimson-text text-xl font-bold">Contact</h3>
              <div className="mt-4 space-y-2">
                <p>
                  <i className="fas fa-map-marker-alt mr-2"></i>Rotterdamseweg
                  381, Delft
                </p>
                <p>
                  <i className="fas fa-phone mr-2"></i>015 - 123 4567
                </p>
                <p>
                  <i className="fas fa-envelope mr-2"></i>
                  info@dedelftschesport.nl
                </p>
              </div>
            </div>
            <div>
              <h3 className="font-crimson-text text-xl font-bold">Volg ons</h3>
              <div className="mt-4 flex space-x-4">
                <a href="#" className="hover:text-[#357AFF] transition">
                  <i className="fab fa-facebook fa-2x"></i>
                </a>
                <a href="#" className="hover:text-[#357AFF] transition">
                  <i className="fab fa-instagram fa-2x"></i>
                </a>
                <a href="#" className="hover:text-[#357AFF] transition">
                  <i className="fab fa-linkedin fa-2x"></i>
                </a>
              </div>
            </div>
            <div>
              <h3 className="font-crimson-text text-xl font-bold">
                Openingstijden
              </h3>
              <div className="mt-4 space-y-2">
                <p>Maandag - Vrijdag: 07:00 - 23:00</p>
                <p>Zaterdag - Zondag: 08:00 - 22:00</p>
              </div>
            </div>
            <div>
              <h3 className="font-crimson-text text-xl font-bold">
                Belangrijke links
              </h3>
              <div className="mt-4 space-y-2">
                <p>
                  <a
                    href="/huisregels"
                    className="hover:text-[#357AFF] transition"
                  >
                    Huisregels
                  </a>
                </p>
                <p>
                  <a
                    href="/privacy"
                    className="hover:text-[#357AFF] transition"
                  >
                    Privacy verklaring
                  </a>
                </p>
                <p>
                  <a
                    href="/contact"
                    className="hover:text-[#357AFF] transition"
                  >
                    Contact
                  </a>
                </p>
              </div>
            </div>
          </div>
          <div className="mt-8 border-t border-gray-700 pt-8 text-center">
            <p>&copy; 2025 RV De Delftsche Sport. Alle rechten voorbehouden.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default MainComponent;