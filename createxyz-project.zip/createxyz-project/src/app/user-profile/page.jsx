"use client";
import React from "react";

function MainComponent() {
  const { data: user, loading } = useUser();
  const [activeTab, setActiveTab] = useState("personal");
  const [notifications, setNotifications] = useState({
    damage_reports: true,
    reservation_reminders: true,
    exam_updates: true,
  });
  const [reservations, setReservations] = useState([]);
  const [damages, setDamages] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const reservationsResponse = await fetch("/api/get-reservations", {
          method: "POST",
          body: JSON.stringify({ userId: user?.id }),
        });
        if (!reservationsResponse.ok)
          throw new Error("Kon reserveringen niet ophalen");
        const reservationsData = await reservationsResponse.json();
        setReservations(reservationsData.reservations || []);

        const damagesResponse = await fetch("/api/get-boat-damages", {
          method: "POST",
          body: JSON.stringify({ reportedBy: user?.id }),
        });
        if (!damagesResponse.ok)
          throw new Error("Kon schademeldingen niet ophalen");
        const damagesData = await damagesResponse.json();
        setDamages(damagesData.damages || []);
      } catch (err) {
        console.error(err);
        setError("Er is een fout opgetreden bij het ophalen van de gegevens");
      }
    };

    if (user?.id) {
      fetchData();
    }
  }, [user?.id]);

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-xl">Laden...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">
            Je moet ingelogd zijn om deze pagina te bekijken
          </h1>
          <a href="/account/signin" className="text-[#357AFF] hover:underline">
            Ga naar inloggen
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      <div className="mx-auto max-w-7xl px-4 py-8">
        <div className="grid gap-8 md:grid-cols-[300px_1fr]">
          <div className="space-y-6">
            <div className="rounded-lg bg-white p-6 shadow">
              <div className="text-center">
                <div className="mx-auto mb-4 h-24 w-24 rounded-full bg-[#357AFF] text-white flex items-center justify-center text-3xl">
                  {user.name?.charAt(0).toUpperCase()}
                </div>
                <h1 className="text-xl font-bold">{user.name}</h1>
                <p className="text-gray-600">{user.email}</p>
              </div>
              <div className="mt-6 border-t pt-4">
                <div className="flex items-center justify-between">
                  <span>Rank</span>
                  <span className="font-semibold">
                    {user.rank_name || "Onbekend"}
                  </span>
                </div>
              </div>
            </div>

            <div className="rounded-lg bg-white p-4 shadow">
              <ul className="space-y-2">
                <li>
                  <button
                    onClick={() => setActiveTab("personal")}
                    className={`w-full rounded-lg p-2 text-left ${
                      activeTab === "personal"
                        ? "bg-[#357AFF] text-white"
                        : "hover:bg-gray-100"
                    }`}
                  >
                    <i className="fas fa-user mr-2"></i>Persoonlijke informatie
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => setActiveTab("activity")}
                    className={`w-full rounded-lg p-2 text-left ${
                      activeTab === "activity"
                        ? "bg-[#357AFF] text-white"
                        : "hover:bg-gray-100"
                    }`}
                  >
                    <i className="fas fa-chart-line mr-2"></i>Activiteit
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => setActiveTab("settings")}
                    className={`w-full rounded-lg p-2 text-left ${
                      activeTab === "settings"
                        ? "bg-[#357AFF] text-white"
                        : "hover:bg-gray-100"
                    }`}
                  >
                    <i className="fas fa-cog mr-2"></i>Instellingen
                  </button>
                </li>
                {user.is_admin && (
                  <li>
                    <button
                      onClick={() => setActiveTab("admin")}
                      className={`w-full rounded-lg p-2 text-left ${
                        activeTab === "admin"
                          ? "bg-[#357AFF] text-white"
                          : "hover:bg-gray-100"
                      }`}
                    >
                      <i className="fas fa-shield-alt mr-2"></i>Admin opties
                    </button>
                  </li>
                )}
              </ul>
            </div>
          </div>

          <div className="rounded-lg bg-white p-6 shadow">
            {error && (
              <div className="mb-4 rounded-lg bg-red-100 p-4 text-red-700">
                <i className="fas fa-exclamation-circle mr-2"></i>
                {error}
              </div>
            )}

            {activeTab === "personal" && (
              <div>
                <h2 className="text-2xl font-bold mb-6">
                  Persoonlijke informatie
                </h2>
                <div className="grid gap-6 md:grid-cols-2">
                  <div>
                    <h3 className="font-bold mb-4">Contact gegevens</h3>
                    <div className="space-y-2">
                      <p>
                        <i className="fas fa-envelope mr-2"></i>
                        {user.email}
                      </p>
                      <p>
                        <i className="fas fa-phone mr-2"></i>
                        {user.phone || "Niet opgegeven"}
                      </p>
                    </div>
                  </div>
                  <div>
                    <h3 className="font-bold mb-4">Behaalde examens</h3>
                    <div className="space-y-2">
                      {user.exams?.map((exam) => (
                        <div key={exam.id} className="flex items-center">
                          <i className="fas fa-certificate text-[#357AFF] mr-2"></i>
                          {exam.name}
                        </div>
                      )) || "Geen examens behaald"}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "activity" && (
              <div>
                <h2 className="text-2xl font-bold mb-6">Activiteit</h2>
                <div className="space-y-6">
                  <div>
                    <h3 className="font-bold mb-4">Komende reserveringen</h3>
                    <div className="space-y-2">
                      {reservations
                        .filter((r) => new Date(r.start_time) > new Date())
                        .map((reservation) => (
                          <div
                            key={reservation.id}
                            className="rounded-lg border p-4"
                          >
                            <div className="flex justify-between">
                              <div>
                                <p className="font-semibold">
                                  {reservation.boat_name}
                                </p>
                                <p className="text-sm text-gray-600">
                                  {new Date(
                                    reservation.start_time
                                  ).toLocaleString()}
                                </p>
                              </div>
                              <a
                                href={`/afschrijfboek/${reservation.id}`}
                                className="text-[#357AFF] hover:underline"
                              >
                                Details
                              </a>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="font-bold mb-4">Schademeldingen</h3>
                    <div className="space-y-2">
                      {damages.map((damage) => (
                        <div key={damage.id} className="rounded-lg border p-4">
                          <p className="font-semibold">{damage.boat_name}</p>
                          <p className="text-sm text-gray-600">
                            {damage.description}
                          </p>
                          <p className="text-sm text-gray-500 mt-2">
                            {new Date(damage.reported_at).toLocaleDateString()}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "settings" && (
              <div>
                <h2 className="text-2xl font-bold mb-6">Instellingen</h2>
                <div className="space-y-6">
                  <div>
                    <h3 className="font-bold mb-4">Email notificaties</h3>
                    <div className="space-y-2">
                      <label className="flex items-center">
                        <input
                          type="checkbox"
                          checked={notifications.damage_reports}
                          onChange={(e) =>
                            setNotifications({
                              ...notifications,
                              damage_reports: e.target.checked,
                            })
                          }
                          className="mr-2"
                        />
                        Schademeldingen
                      </label>
                      <label className="flex items-center">
                        <input
                          type="checkbox"
                          checked={notifications.reservation_reminders}
                          onChange={(e) =>
                            setNotifications({
                              ...notifications,
                              reservation_reminders: e.target.checked,
                            })
                          }
                          className="mr-2"
                        />
                        Reserveringsherinneringen
                      </label>
                      <label className="flex items-center">
                        <input
                          type="checkbox"
                          checked={notifications.exam_updates}
                          onChange={(e) =>
                            setNotifications({
                              ...notifications,
                              exam_updates: e.target.checked,
                            })
                          }
                          className="mr-2"
                        />
                        Examen updates
                      </label>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-bold mb-4">Account</h3>
                    <div className="space-y-4">
                      <a
                        href="/account/change-password"
                        className="inline-block rounded-lg bg-gray-100 px-4 py-2 text-gray-700 hover:bg-gray-200"
                      >
                        <i className="fas fa-key mr-2"></i>Wachtwoord wijzigen
                      </a>
                      <button className="block rounded-lg bg-gray-100 px-4 py-2 text-gray-700 hover:bg-gray-200">
                        <i className="fas fa-edit mr-2"></i>Profiel bewerken
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "admin" && user.is_admin && (
              <div>
                <h2 className="text-2xl font-bold mb-6">Admin opties</h2>
                <div className="space-y-4">
                  <a
                    href="/beheer"
                    className="block rounded-lg bg-[#357AFF] px-4 py-2 text-white hover:bg-[#2E69DE]"
                  >
                    <i className="fas fa-users-cog mr-2"></i>Gebruikersbeheer
                  </a>
                  <a
                    href="/beheer/examens"
                    className="block rounded-lg bg-[#357AFF] px-4 py-2 text-white hover:bg-[#2E69DE]"
                  >
                    <i className="fas fa-graduation-cap mr-2"></i>Examenbeheer
                  </a>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;